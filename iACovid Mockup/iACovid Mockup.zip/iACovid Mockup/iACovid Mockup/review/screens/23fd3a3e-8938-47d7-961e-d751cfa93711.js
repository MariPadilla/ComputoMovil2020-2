var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-23fd3a3e-8938-47d7-961e-d751cfa93711" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 7" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/23fd3a3e-8938-47d7-961e-d751cfa93711-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/23fd3a3e-8938-47d7-961e-d751cfa93711-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/23fd3a3e-8938-47d7-961e-d751cfa93711-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="50px" dataX="295" dataY="48"   alt="image">\
          <img src="./images/aabe8057-8e43-41be-af2d-3e058f46c542.png" />\
      </div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="62px" dataX="282" dataY="663" >\
        <div id="s-Button_1" class="pie button singleline firer click commentable non-processed"   datasizewidth="62px" datasizeheight="62px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0"></span></div></div></div></div>\
        <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="11" dataY="11"   alt="image" systemName="./images/95cdbaa7-a269-47c4-8d09-153955838f81.svg" overlay="#434343">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path stroke="#000" stroke-linejoin="round" stroke-miterlimit="10" d="M23.5 10.759c0 5.181-5.148 9.384-11.5 9.384-1.418 0-2.775-.211-4.029-.594l-6.608 3.076 2.588-5.166c-2.129-1.703-3.45-4.076-3.45-6.7 0-5.182 5.148-9.383 11.5-9.383s11.499 4.201 11.499 9.383z" fill="none"/></svg>\
        </div>\
      </div>\
      <div id="s-Button_2" class="pie button singleline firer click commentable non-processed"   datasizewidth="313px" datasizeheight="79px" dataX="27" dataY="186" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_2_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="95px" datasizeheight="70px" dataX="136" dataY="97" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Chat</span></div></div></div></div>\
      <div id="s-Image_28" class="pie image firer click ie-background commentable non-processed"   datasizewidth="49px" datasizeheight="49px" dataX="42" dataY="201"   alt="image" systemName="./images/68ad3db6-9e2d-4e34-877e-3b3c5dd4ce0e.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 0c-6.617 0-12 5.383-12 12 0 3.18 1.232 6.177 3.469 8.438v.001c2.274 2.296 5.303 3.561 8.531 3.561 3.234 0 6.268-1.27 8.542-3.573 2.23-2.261 3.458-5.253 3.458-8.427 0-6.617-5.383-12-12-12zm8.095 19.428c-1.055-.626-2.64-1.202-4.32-1.81l-1.275-.465v-1.848c.501-.309 1.384-1.107 1.49-2.935.386-.227.63-.728.63-1.37 0-.578-.197-1.043-.52-1.294.242-.757.681-2.145.385-3.327-.347-1.387-2.229-1.879-3.735-1.879-1.342 0-2.982.391-3.569 1.456-.704-.034-1.096.273-1.29.531-.635.838-.216 2.368.021 3.21-.329.249-.532.718-.532 1.303 0 .643.244 1.144.63 1.37.106 1.828.989 2.626 1.49 2.935v1.848l-1.176.431c-1.621.587-3.288 1.194-4.407 1.857-1.877-2.036-2.917-4.659-2.917-7.441 0-6.065 4.935-11 11-11s11 4.935 11 11c0 2.775-1.035 5.394-2.905 7.428z"/></svg>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext firer click ie-background commentable non-processed"   datasizewidth="200px" datasizeheight="36px" dataX="110" dataY="221" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Hey! &iquest;Qu&eacute; cuentas? &iquest;Qu&eacute; tal te &nbsp; <br />ha ido con la aplicaci&oacute;n?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="94px" datasizeheight="23px" dataX="162" dataY="193" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Mari Bostwick</span></div></div></div></div>\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" datasizewidth="30px" datasizeheight="30px" dataX="298" dataY="190" >\
        <div id="shapewrapper-s-Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="0" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="11px" datasizeheight="26px" dataX="9" dataY="2" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">1</span></div></div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;