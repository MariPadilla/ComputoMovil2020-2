var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-57b4c937-8604-4aa0-91f3-5c565a4ac1af" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 13" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/57b4c937-8604-4aa0-91f3-5c565a4ac1af-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/57b4c937-8604-4aa0-91f3-5c565a4ac1af-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/57b4c937-8604-4aa0-91f3-5c565a4ac1af-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="53px" datasizeheight="35px" dataX="161" dataY="109" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Perfil</span></div></div></div></div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="127px" datasizeheight="126px" dataX="124" dataY="153" >\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="127px" datasizeheight="126px" dataX="0" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="63.5" cy="63.0" rx="63.5" ry="63.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="63.5" cy="63.0" rx="63.5" ry="63.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="79px" datasizeheight="71px" dataX="24" dataY="27"   alt="image" systemName="./images/ab2343aa-ea8f-4027-b0f1-2bd2a21ac70e.svg" overlay="#000000">\
            <svg preserveAspectRatio=\'none\' id="s-Image_2-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_2 .cls-1{fill:#666;}</style></defs><title>user_2</title><path id="s-Image_2-user_2" class="cls-1" d="M36.7,32.66a13,13,0,1,0-11.41,0A25,25,0,0,0,6,57a1,1,0,0,0,2,0,23,23,0,0,1,46,0,1,1,0,0,0,2,0A25,25,0,0,0,36.7,32.66ZM20,21A11,11,0,1,1,31,32,11,11,0,0,1,20,21Z"/></svg>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="90px" datasizeheight="28px" dataX="143" dataY="278" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Editar foto</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="187px" datasizeheight="23px" dataX="30" dataY="315" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Cambiar nombre de usuario</span></div></div></div></div>\
      <div id="s-Input_2" class="pie text firer keyup commentable non-processed"  datasizewidth="272px" datasizeheight="28px" dataX="52" dataY="345" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="193px" datasizeheight="23px" dataX="27" dataY="392" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Cambiar direcci&oacute;n de e-mail</span></div></div></div></div>\
      <div id="s-Input_3" class="pie text firer keyup commentable non-processed"  datasizewidth="272px" datasizeheight="28px" dataX="52" dataY="424" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="219px" datasizeheight="23px" dataX="27" dataY="469" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Cambiar el color de la aplicaci&oacute;n</span></div></div></div></div>\
      <div id="s-Category_3" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="100px" datasizeheight="28px" dataX="257" dataY="467"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value"></div></div><select id="s-Category_3-options" class="s-57b4c937-8604-4aa0-91f3-5c565a4ac1af dropdown-options" ><option selected="selected" class="option"><br /></option>\
      <option  class="option">Verde</option>\
      <option  class="option">Azul</option>\
      <option  class="option">Rosa</option>\
      <option  class="option">Amarillo</option>\
      <option  class="option">Rojo</option>\
      <option  class="option">Negro</option>\
      <option  class="option">Blanco</option></select></div>\
      <div id="s-Category_4" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="71px" datasizeheight="28px" dataX="274" dataY="506"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value"></div></div><select id="s-Category_4-options" class="s-57b4c937-8604-4aa0-91f3-5c565a4ac1af dropdown-options" ><option selected="selected" class="option"><br /></option>\
      <option  class="option">10%</option>\
      <option  class="option">5%</option>\
      <option  class="option">25%</option></select></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="180px" datasizeheight="23px" dataX="27" dataY="508" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Selecciona el tono del color</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="241px" datasizeheight="23px" dataX="25" dataY="553" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Selecciona el mensaje de bienvenida</span></div></div></div></div>\
      <div id="s-Button_1" class="pie button singleline firer ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="35px" dataX="281" dataY="588" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0">Ok</span></div></div></div></div>\
      <div id="s-Button_2" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="117px" datasizeheight="38px" dataX="134" dataY="654" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_2_0">Confirmar</span></div></div></div></div>\
      <div id="s-Input_4" class="pie text firer keyup commentable non-processed"  datasizewidth="241px" datasizeheight="28px" dataX="25" dataY="592" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;