var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-41f0b415-c70a-4de2-8e93-e2ce42598061" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 4.9.2" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/41f0b415-c70a-4de2-8e93-e2ce42598061-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/41f0b415-c70a-4de2-8e93-e2ce42598061-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/41f0b415-c70a-4de2-8e93-e2ce42598061-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Button_1" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="50px" dataX="-2" dataY="727" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0">Estatus</span></div></div></div></div>\
      <div id="s-Button_3" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="50px" dataX="224" dataY="727" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_3_0">Check List</span></div></div></div></div>\
      <div id="s-Button_4" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="50px" dataX="73" dataY="727" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_4_0">Informaci&oacute;n</span></div></div></div></div>\
      <div id="s-Button_5" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="50px" dataX="149" dataY="727" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_5_0">Alert</span></div></div></div></div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="127px" datasizeheight="126px" dataX="123" dataY="127" >\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="127px" datasizeheight="126px" dataX="0" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="63.5" cy="63.0" rx="63.5" ry="63.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="63.5" cy="63.0" rx="63.5" ry="63.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="79px" datasizeheight="71px" dataX="24" dataY="27"   alt="image" systemName="./images/ab2343aa-ea8f-4027-b0f1-2bd2a21ac70e.svg" overlay="#000000">\
            <svg preserveAspectRatio=\'none\' id="s-Image_1-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_1 .cls-1{fill:#666;}</style></defs><title>user_2</title><path id="s-Image_1-user_2" class="cls-1" d="M36.7,32.66a13,13,0,1,0-11.41,0A25,25,0,0,0,6,57a1,1,0,0,0,2,0,23,23,0,0,1,46,0,1,1,0,0,0,2,0A25,25,0,0,0,36.7,32.66ZM20,21A11,11,0,1,1,31,32,11,11,0,0,1,20,21Z"/></svg>\
        </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="200px" datasizeheight="52px" dataX="87" dataY="286" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Hey, Marco.</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="162px" datasizeheight="35px" dataX="16" dataY="373" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Pr&oacute;xima Alerta:</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline firer click commentable non-processed"   datasizewidth="299px" datasizeheight="62px" dataX="53" dataY="417" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Entrada &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;7 a.m.</span></div></div></div></div>\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" datasizewidth="70px" datasizeheight="70px" dataX="24" dataY="537" >\
        <div id="s-Button_2" class="pie button singleline firer click commentable non-processed"   datasizewidth="70px" datasizeheight="70px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_2_0"></span></div></div></div></div>\
        <div id="s-Image_4" class="pie image firer click ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="38px" dataX="13" dataY="16"   alt="image" systemName="./images/4d9174c1-10e2-48a9-9fd5-1c9ed2bdab85.svg" overlay="#666666">\
            <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g stroke="#000" stroke-linejoin="round" stroke-miterlimit="10" fill="none"><path d="M8.074 10.213c-.656-1.311-2.008-2.213-3.574-2.213-2.209 0-4 1.791-4 4s1.791 4 4 4c1.566 0 2.918-.902 3.574-2.213M19.5 8.5c2.209 0 4-1.791 4-4s-1.791-4-4-4-4 1.791-4 4c0 .643.156 1.248.424 1.787M15.924 17.713c-1.326 2.648.6 5.787 3.576 5.787 2.209 0 4-1.791 4-4s-1.791-4-4-4M19.5 8.5c-1.566 0-2.918-.902-3.576-2.213l-7.85 3.926c.27.537.426 1.143.426 1.787 0 .643-.156 1.248-.426 1.787l7.85 3.926c.658-1.311 2.01-2.213 3.576-2.213"/></g></svg>\
        </div>\
      </div>\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" datasizewidth="78px" datasizeheight="77px" dataX="110" dataY="533" >\
        <div id="s-Button_6" class="pie button singleline firer click commentable non-processed"   datasizewidth="70px" datasizeheight="70px" dataX="0" dataY="7" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_6_0"></span></div></div></div></div>\
        <div id="s-Image_5" class="pie image firer click ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="10" dataY="17"   alt="image" systemName="./images/af7aba6a-c49a-44d8-a2b6-e0177004e877.svg" overlay="#666666">\
            <svg preserveAspectRatio=\'none\' id="s-Image_5-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_5 .cls-1{fill:#666;}</style></defs><title>chats</title><path class="cls-1" d="M46,27c0-9.37-9.42-17-21-17S4,17.63,4,27A15.25,15.25,0,0,0,9.1,38.12L8,44.84A1,1,0,0,0,9,46a1,1,0,0,0,.5-0.13l6.28-3.59A25.21,25.21,0,0,0,25,44C36.58,44,46,36.37,46,27ZM15.21,40.3l-4.89,2.79,0.84-5.19A1,1,0,0,0,10.83,37,13.36,13.36,0,0,1,6,27c0-8.27,8.52-15,19-15s19,6.73,19,15S35.48,42,25,42a23.32,23.32,0,0,1-8.91-1.75A1,1,0,0,0,15.21,40.3Z"/><path class="cls-1" d="M48.11,19.7a1,1,0,0,0-.73,1.87C53.93,24.12,58,29.27,58,35a13.34,13.34,0,0,1-4.82,10,1,1,0,0,0-.35.93l0.84,5.19L48.78,48.3a1,1,0,0,0-.88,0A23.23,23.23,0,0,1,39,50a22,22,0,0,1-12.64-3.83,1,1,0,0,0-1.15,1.63A24,24,0,0,0,39,52a25.21,25.21,0,0,0,9.22-1.72l6.28,3.59A1,1,0,0,0,55,54a1,1,0,0,0,1-1.16L54.9,46.12A15.25,15.25,0,0,0,60,35C60,28.42,55.44,22.56,48.11,19.7Z"/></svg>\
        </div>\
        <div id="shapewrapper-s-Ellipse_2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="48" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_2)">\
                            <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                            <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_2" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_2_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="11px" datasizeheight="26px" dataX="57" dataY="2" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">1</span></div></div></div></div>\
      </div>\
      <div id="s-Button_9" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="76px" datasizeheight="50px" dataX="300" dataY="727" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_9_0">Ajustes</span></div></div></div></div>\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" datasizewidth="70px" datasizeheight="70px" dataX="195" dataY="537" >\
        <div id="s-Button_7" class="pie button singleline firer click commentable non-processed"   datasizewidth="70px" datasizeheight="70px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_7_0"></span></div></div></div></div>\
        <div id="s-Image_7" class="pie image firer click ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="13" dataY="10"   alt="image" systemName="./images/dd6c243e-d23c-47d8-9c40-77a503517fa0.svg" overlay="#666666">\
            <svg preserveAspectRatio=\'none\' id="s-Image_7-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_7 .cls-1{fill:#666;}</style></defs><title>user_search_2</title><path id="s-Image_7-user_search_2" class="cls-1" d="M50,34a10,10,0,0,0-7.74,16.32l-8,8a1,1,0,1,0,1.41,1.41l8-8A10,10,0,1,0,50,34Zm0,18a8,8,0,1,1,8-8A8,8,0,0,1,50,52ZM42.79,32.27a22.89,22.89,0,0,0-10.49-5.64,11,11,0,1,0-10.6,0A23,23,0,0,0,4,49a1,1,0,0,0,2,0A21,21,0,0,1,41.42,33.73,1,1,0,0,0,42.79,32.27ZM18,17a9,9,0,1,1,9,9A9,9,0,0,1,18,17Z"/></svg>\
        </div>\
      </div>\
      <div id="s-Group_5" class="group firer ie-background commentable non-processed" datasizewidth="70px" datasizeheight="70px" dataX="280" dataY="537" >\
        <div id="s-Button_8" class="pie button singleline firer click commentable non-processed"   datasizewidth="70px" datasizeheight="70px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_8_0"></span></div></div></div></div>\
        <div id="s-Image_18" class="pie image firer click ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="12" dataY="10"   alt="image" systemName="./images/311f3d7f-a168-4cdf-93aa-2a36633ba080.svg" overlay="#666666">\
            <svg preserveAspectRatio=\'none\' id="s-Image_18-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_18 .cls-1{fill:#666;}</style></defs><title>warning</title><path class="cls-1" d="M31,48a3,3,0,1,0-3-3A3,3,0,0,0,31,48Zm0-4a1,1,0,1,1-1,1A1,1,0,0,1,31,44Z"/><path class="cls-1" d="M31,40a3,3,0,0,0,3-3V21a3,3,0,0,0-6,0V37A3,3,0,0,0,31,40ZM30,21a1,1,0,0,1,2,0V37a1,1,0,0,1-2,0V21Z"/><path class="cls-1" d="M9,56H53a7,7,0,0,0,7-7,8.7,8.7,0,0,0-.73-3.11,1,1,0,0,0-.08-0.14L36.75,11l-0.06-.1a7,7,0,0,0-11.38,0l-0.06.1L2.8,45.76s0,0.09-.08.14A8.86,8.86,0,0,0,2,49,7,7,0,0,0,9,56ZM4.53,46.77L27,12a0,0,0,0,1,0,0A5,5,0,0,1,35,12a0,0,0,0,0,0,0L57.47,46.77A6.82,6.82,0,0,1,58,49a5,5,0,0,1-5,5H9a5,5,0,0,1-5-5A6.82,6.82,0,0,1,4.53,46.77Z"/></svg>\
        </div>\
      </div>\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" datasizewidth="70px" datasizeheight="70px" dataX="149" dataY="624" >\
        <div id="s-Button_10" class="pie button singleline firer click commentable non-processed"   datasizewidth="70px" datasizeheight="70px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_10_0"></span></div></div></div></div>\
\
        <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="60px" dataX="5" dataY="5"   alt="image">\
            <img src="./images/73bc3b8a-1477-40aa-9b5e-1874c1d4e298.png" />\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="23" dataY="733"   alt="image">\
          <img src="./images/69e6fa46-fa3b-4fbc-8c27-1e96a9e76f42.png" />\
      </div>\
\
      <div id="s-Image_6" class="pie image firer click ie-background commentable non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="98" dataY="733"   alt="image">\
          <img src="./images/4ea025f1-27d2-43fe-abda-44e33dfcf789.png" />\
      </div>\
\
      <div id="s-Image_8" class="pie image firer click ie-background commentable non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="174" dataY="733"   alt="image">\
          <img src="./images/27eb161f-0c1f-4c0f-bcb4-3fa46cae99c1.png" />\
      </div>\
\
      <div id="s-Image_9" class="pie image firer click ie-background commentable non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="249" dataY="733"   alt="image">\
          <img src="./images/66c0f688-d5c8-45df-9910-6dae947f7525.png" />\
      </div>\
\
      <div id="s-Image_10" class="pie image firer click ie-background commentable non-processed"   datasizewidth="26px" datasizeheight="26px" dataX="325" dataY="733"   alt="image">\
          <img src="./images/15ba5ce5-7faf-4a47-b23f-937cebb2cd7e.png" />\
      </div>\
\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="290" dataY="56"   alt="image">\
          <img src="./images/5aa82dca-7da6-496c-8e14-35753d78d225.png" />\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="268px" datasizeheight="154px" dataX="56" dataY="295" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"><br />&iquest;Permitir que la aplicaci&oacute;n <br />pueda acceder a los archivos?</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Button_11" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="178px" datasizeheight="27px" dataX="101" dataY="407" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_11_0">Rechazar</span></div></div></div></div>\
      <div id="s-Button_12" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="178px" datasizeheight="27px" dataX="101" dataY="373" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_12_0">Permitir</span></div></div></div></div>\
      <div id="s-Image_23" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="290" dataY="320"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' id="s-Image_23-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_23 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_23-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_24" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="60" dataY="320"  rotationdeg="180" alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#FFFFFF">\
          <svg preserveAspectRatio=\'none\' id="s-Image_24-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_24 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_24-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;