var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-69ac48ba-f9cd-4fcf-8cfb-91311063d95b" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 20" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/69ac48ba-f9cd-4fcf-8cfb-91311063d95b-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/69ac48ba-f9cd-4fcf-8cfb-91311063d95b-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/69ac48ba-f9cd-4fcf-8cfb-91311063d95b-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="71px" datasizeheight="35px" dataX="135" dataY="103" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Alertas</span></div></div></div></div>\
      <div id="s-Image_34" class="pie image firer click ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="302" dataY="700"   alt="image" systemName="./images/06f2128d-00db-476c-9fca-2260c5488514.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.646 3.384c-2.167-2.177-5.052-3.378-8.147-3.384-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.499-11.479.006-3.071-1.185-5.961-3.353-8.137zm-8.146 19.116zm5.999-10.488l-5.5-.006v5.494c0 .276-.225.5-.5.5-.276 0-.5-.224-.5-.5v-5.495l-5.501-.005c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l5.5.005v-5.505c0-.276.224-.5.5-.5.275 0 .5.224.5.5v5.506l5.501.006c.275 0 .5.224.499.5 0 .276-.224.5-.5.5z"/></svg>\
      </div>\
      <div id="s-Button_1" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="256px" datasizeheight="60px" dataX="23" dataY="158" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0"></span></div></div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext firer click ie-background commentable non-processed"   datasizewidth="237px" datasizeheight="43px" dataX="32" dataY="166" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">08:00 a.m. | Entrada<br />Todos los d&iacute;as | Sonar&aacute; en 2 horas y...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Toggle-on" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="38px" dataX="285" dataY="169" >\
        <div id="s-Panel_15" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_18" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_18_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_11" class="shapewrapper shapewrapper-s-Ellipse_11 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="26" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_11" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_11)">\
                                  <ellipse id="s-Ellipse_11" class="pie ellipse shape non-processed-shape firer click swipeleft commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_11" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_11" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_11_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_16" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_19" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_19_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_12" class="shapewrapper shapewrapper-s-Ellipse_12 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="8" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_12" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_12)">\
                                  <ellipse id="s-Ellipse_12" class="pie ellipse shape non-processed-shape firer click swiperight commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_12" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_12" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_12_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="50px" datasizeheight="50px" dataX="229" dataY="700" >\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="0" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="25.0" cy="25.0" rx="25.0" ry="25.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="25.0" cy="25.0" rx="25.0" ry="25.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
\
        <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="5" dataY="5"   alt="image">\
            <img src="./images/af25f65f-70f2-4e9a-b9f8-e7a23e1bc0f7.png" />\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;