function initData() {
  jimData.variables["Listo"] = "0";
  jimData.isInitialized = true;
}