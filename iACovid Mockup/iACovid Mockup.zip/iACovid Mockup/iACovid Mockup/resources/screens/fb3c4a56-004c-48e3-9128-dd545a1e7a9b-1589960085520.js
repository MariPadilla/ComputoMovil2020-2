jQuery("#simulation")
  .on("click", ".s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_4" ],
                    "value": ""
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_5" ],
                    "value": ""
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_1")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_4",
                    "property": "jimGetValue"
                  },"marco" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_5",
                    "property": "jimGetValue"
                  },"perrito" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f",
                    "transition": {
                      "type": "slideleft",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b #s-Input_4 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF8A8D",
                        "border-top-width": "2px",
                        "border-top-color": "#FF0D0D",
                        "border-right-width": "2px",
                        "border-right-color": "#FF0D0D",
                        "border-bottom-width": "2px",
                        "border-bottom-color": "#FF0D0D",
                        "border-left-width": "2px",
                        "border-left-color": "#FF0D0D"
                      }
                    }
                  },{
                    "#s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b #s-Input_4": {
                      "attributes-ie": {
                        "-pie-background": "#FF8A8D",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b #s-Input_5 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF8A8D",
                        "border-top-width": "2px",
                        "border-top-color": "#FF0D0D",
                        "border-right-width": "2px",
                        "border-right-color": "#FF0D0D",
                        "border-bottom-width": "2px",
                        "border-bottom-color": "#FF0D0D",
                        "border-left-width": "2px",
                        "border-left-color": "#FF0D0D"
                      }
                    }
                  },{
                    "#s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b #s-Input_5": {
                      "attributes-ie": {
                        "-pie-background": "#FF8A8D",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b #s-Input_5 INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_4" ],
                    "value": "Usuario o contraseña incorrectos."
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("keyup.jim", ".s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b .keyup", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.which === 13 && data.ctrlKey === false && data.shiftKey === false && data.altKey === false),
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Input_4" ],
                    "value": {
                      "datatype": "property",
                      "target": "#s-Input_4",
                      "property": "jimGetValue"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      if(!jimUtil.isAndroidDevice() || data.which != 229)
      	jEvent.launchCases(cases);
      if(data.which === 9) {
        return false;
      }
    }
  });