var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1f332b31-31df-4f68-b2b1-7d1d471bf4e1" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 25" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/1f332b31-31df-4f68-b2b1-7d1d471bf4e1-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/1f332b31-31df-4f68-b2b1-7d1d471bf4e1-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/1f332b31-31df-4f68-b2b1-7d1d471bf4e1-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="48px" datasizeheight="35px" dataX="174" dataY="95" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Todo</span></div></div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="304px" datasizeheight="17px" dataX="49" dataY="129" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Al lograr los objetivos puedes conseguir mejoras en la aplicaci&oacute;n </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="165"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="222"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="279"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="336"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="393"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="452"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_9" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="509"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_10" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="566"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_11" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="79" dataY="624"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="23px" dataX="148" dataY="178" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Modo nocturno</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="178" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">25</span></div></div></div></div>\
\
      <div id="s-Image_12" class="pie image firer ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="297" dataY="175"   alt="image">\
          <img src="./images/3ad9caa4-e178-46e6-baad-33d7c4e7dc82.png" />\
      </div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="235" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">18</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="23px" dataX="54" dataY="292" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">4</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="349" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">37</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="406" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">24</span></div></div></div></div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="465" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">40</span></div></div></div></div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="522" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">43</span></div></div></div></div>\
      <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="579" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">19</span></div></div></div></div>\
      <div id="s-Text_12" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="23px" dataX="49" dataY="637" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">30</span></div></div></div></div>\
      <div id="s-Text_13" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="68px" datasizeheight="23px" dataX="167" dataY="235" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">Rosa coral</span></div></div></div></div>\
\
      <div id="s-Image_13" class="pie image firer ie-background commentable non-processed"   datasizewidth="41px" datasizeheight="21px" dataX="291" dataY="228"   alt="image">\
          <img src="./images/8ceb1406-2212-49ef-9995-becbaf10c607.png" />\
      </div>\
      <div id="s-Text_14" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="23px" dataX="178" dataY="292" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">Violeta</span></div></div></div></div>\
\
      <div id="s-Image_14" class="pie image firer ie-background commentable non-processed"   datasizewidth="41px" datasizeheight="21px" dataX="291" dataY="287"   alt="image">\
          <img src="./images/16093b7a-273c-40cd-86c6-a748e876e99b.png" />\
      </div>\
      <div id="s-Text_15" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="86px" datasizeheight="23px" dataX="158" dataY="349" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_15_0">Icono de lobo</span></div></div></div></div>\
\
      <div id="s-Image_15" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="287" dataY="330"   alt="image">\
          <img src="./images/b7c502e4-8f1b-495c-977d-169ff9a06b40.png" />\
      </div>\
      <div id="s-Text_16" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="105px" datasizeheight="23px" dataX="148" dataY="406" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_16_0">Icono de ajustes</span></div></div></div></div>\
\
      <div id="s-Image_16" class="pie image firer ie-background commentable non-processed"   datasizewidth="70px" datasizeheight="40px" dataX="277" dataY="393"   alt="image">\
          <img src="./images/c023d692-3a23-4f96-b3f7-465dad63bbd8.png" />\
      </div>\
\
      <div id="s-Image_18" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="287" dataY="624"   alt="image">\
          <img src="./images/6e0aa440-b8bb-4b1f-8592-787fea48991e.png" />\
      </div>\
      <div id="s-Text_18" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="133px" datasizeheight="23px" dataX="134" dataY="637" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_18_0">Icono de Mario Bros</span></div></div></div></div>\
      <div id="s-Text_20" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="89px" datasizeheight="23px" dataX="153" dataY="575" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_20_0">Icono de chat</span></div></div></div></div>\
\
      <div id="s-Image_21" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="287" dataY="564"   alt="image">\
          <img src="./images/91bb033d-b3b7-480f-ba29-ce58d62c7a2c.png" />\
      </div>\
      <div id="s-Text_21" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="137px" datasizeheight="23px" dataX="132" dataY="518" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_21_0">Icono de Jotaro Kujo</span></div></div></div></div>\
\
      <div id="s-Image_22" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="287" dataY="507"   alt="image">\
          <img src="./images/f4070c3e-2721-4e5a-86f8-5dfe0e5e2aeb.png" />\
      </div>\
      <div id="s-Text_22" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="136px" datasizeheight="19px" dataX="133" dataY="465" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_22_0">Icono de Tanjiro Kamado</span></div></div></div></div>\
\
      <div id="s-Image_20" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="287" dataY="448"   alt="image">\
          <img src="./images/7b4b6307-86f7-44fc-aa66-69711e52ba0d.png" />\
      </div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="45px" datasizeheight="47px" dataX="175" dataY="700" >\
        <div id="s-Image_19" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="45px" dataX="0" dataY="0"   alt="image" systemName="./images/1788a8c1-0e19-4fab-87a2-812f3c136a86.svg" overlay="#434343">\
            <?xml version="1.0" encoding="utf-8"?>\
            <!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
            <svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_19-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">\
            <path id="s-Image_19-more" fill="#666666" d="M11,38c-2.757,0-5-2.243-5-5s2.243-5,5-5s5,2.243,5,5S13.757,38,11,38z M11,30\
            	c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3s3-1.346,3-3C14,31.346,12.654,30,11,30z M31,38c-2.757,0-5-2.243-5-5s2.243-5,5-5\
            	s5,2.243,5,5S33.757,38,31,38z M31,30c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3c1.654,0,3-1.346,3-3C34,31.346,32.654,30,31,30z\
            	 M51,38c-2.757,0-5-2.243-5-5s2.243-5,5-5s5,2.243,5,5S53.757,38,51,38z M51,30c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3\
            	s3-1.346,3-3C54,31.346,52.654,30,51,30z"/>\
            </svg>\
\
        </div>\
        <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="34px" datasizeheight="20px" dataX="6" dataY="27" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">More</span></div></div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;