var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-294abed7-be54-4cca-8dc0-82d4935425f7" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 23" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/294abed7-be54-4cca-8dc0-82d4935425f7-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/294abed7-be54-4cca-8dc0-82d4935425f7-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/294abed7-be54-4cca-8dc0-82d4935425f7-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="35px" dataX="34" dataY="51"   alt="image" systemName="./images/13a00661-8a5f-4f94-b354-e958cb88c93a.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.003 10.998h-19.429l10.104-9.263c.407-.373.435-1.006.062-1.413-.373-.406-1.006-.435-1.413-.062l-12 11-.015.017-.079.09-.051.061-.067.119-.029.055-.052.158-.01.033-.021.205.021.205.01.032.052.16.029.054.067.119.05.061.08.09.015.017 12 11c.191.176.434.263.676.263.27 0 .54-.109.737-.324.373-.407.346-1.039-.062-1.413l-10.104-9.264h19.429c.552 0 1-.447 1-1 0-.552-.448-1-1-1z"/></svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="103px" datasizeheight="35px" dataX="132" dataY="108" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Check List</span></div></div></div></div>\
      <div id="s-Image_34" class="pie image firer ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="164" dataY="594"   alt="image" systemName="./images/06f2128d-00db-476c-9fca-2260c5488514.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.646 3.384c-2.167-2.177-5.052-3.378-8.147-3.384-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.499-11.479.006-3.071-1.185-5.961-3.353-8.137zm-8.146 19.116zm5.999-10.488l-5.5-.006v5.494c0 .276-.225.5-.5.5-.276 0-.5-.224-.5-.5v-5.495l-5.501-.005c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l5.5.005v-5.505c0-.276.224-.5.5-.5.275 0 .5.224.5.5v5.506l5.501.006c.275 0 .5.224.499.5 0 .276-.224.5-.5.5z"/></svg>\
      </div>\
      <div id="s-Image_40" class="pie image firer click variablechange ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="159" dataY="678"   alt="image" systemName="./images/39b92206-c0ef-4c76-a68a-289733fce9ae.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="65px" datasizeheight="28px" dataX="106" dataY="167" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Monitor</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="28px" dataX="107" dataY="200" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Teclado</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="49px" datasizeheight="28px" dataX="107" dataY="233" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Mouse</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="56px" datasizeheight="28px" dataX="110" dataY="266" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Laptop</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="42px" datasizeheight="28px" dataX="111" dataY="300" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Pesas</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="98px" datasizeheight="28px" dataX="111" dataY="335" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Caminadora</span></div></div></div></div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="56px" datasizeheight="28px" dataX="111" dataY="370" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">Celular</span></div></div></div></div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="95px" datasizeheight="28px" dataX="111" dataY="403" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">Banco press</span></div></div></div></div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="163px" datasizeheight="28px" dataX="111" dataY="437" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">M&aacute;quina de dorsales</span></div></div></div></div>\
      <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="125px" datasizeheight="28px" dataX="111" dataY="473" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">&Aacute;rea de trabajo</span></div></div></div></div>\
      <div id="s-Text_12" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="68px" datasizeheight="28px" dataX="113" dataY="509" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">Bicicleta</span></div></div></div></div>\
      <div id="s-Text_13" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="28px" dataX="114" dataY="543" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">iPad</span></div></div></div></div>\
\
        <div id="s-Input_4" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="167"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_5" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="200"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_6" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="233"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_7" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="266"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_8" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="300"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_9" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="335"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_10" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="370"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_11" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="403"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_12" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="437"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_13" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="473"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_14" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="509"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
        <div id="s-Input_15" class="pie inputIOS checkbox firer commentable non-processed"  datasizewidth="28px" datasizeheight="28px" dataX="38" dataY="543"      tabindex="-1">\
          <div class="backgroundLayer"></div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;