var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-e76cc449-c950-4cb7-926f-29ace102db3e" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 17" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e76cc449-c950-4cb7-926f-29ace102db3e-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/e76cc449-c950-4cb7-926f-29ace102db3e-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/e76cc449-c950-4cb7-926f-29ace102db3e-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="120px" datasizeheight="35px" dataX="131" dataY="95" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Informaci&oacute;n</span></div></div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="280px" datasizeheight="72px" dataX="51" dataY="129" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Selecciona la imagen de aquella informaci&oacute;n que desees consultar ya sea sobre qu&eacute; es el COVID-19, sus s&iacute;ntomas, etc, y la aplicaci&oacute;n te mostrar&aacute; dicha informaci&oacute;n.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="155px" datasizeheight="23px" dataX="11" dataY="212" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">&iquest;Qu&eacute; es el coronavirus?</span></div></div></div></div>\
\
      <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed"   datasizewidth="280px" datasizeheight="85px" dataX="51" dataY="234"   alt="image">\
          <img src="./images/5758a6d6-897b-4f26-956e-17efcc3f9f93.jpg" />\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="23px" dataX="11" dataY="326" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">S&iacute;ntomas</span></div></div></div></div>\
\
      <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed"   datasizewidth="280px" datasizeheight="95px" dataX="51" dataY="348"   alt="image">\
          <img src="./images/c4cc8db3-2ee4-409f-b49e-a153e67ee636.png" />\
      </div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="138px" datasizeheight="23px" dataX="11" dataY="453" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">&iquest;C&oacute;mo se transmite?</span></div></div></div></div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="280px" datasizeheight="101px" dataX="51" dataY="475"   alt="image">\
          <img src="./images/65b30bf4-dc43-4e6e-a280-54cf115f4e8d.png" />\
      </div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="130px" datasizeheight="23px" dataX="11" dataY="592" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">&iquest;C&oacute;mo prevenirme?</span></div></div></div></div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="280px" datasizeheight="74px" dataX="51" dataY="614"   alt="image">\
          <img src="./images/4912dbc8-8231-40e3-ba8e-cf7389cfbebd.png" />\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="222px" datasizeheight="34px" dataX="29" dataY="705" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Para mas informaci&oacute;n da click en la imagen y te llevar&aacute; a la p&aacute;gina oficial de la OMS.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="63px" datasizeheight="58px" dataX="268" dataY="693"   alt="image">\
          <img src="./images/eb8eb47a-9336-4834-8f86-cc4cf910e5cc.png" />\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;