var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-fb3c4a56-004c-48e3-9128-dd545a1e7a9b" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 4" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/fb3c4a56-004c-48e3-9128-dd545a1e7a9b-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/fb3c4a56-004c-48e3-9128-dd545a1e7a9b-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/fb3c4a56-004c-48e3-9128-dd545a1e7a9b-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="165px" datasizeheight="146px" dataX="105" dataY="87" >\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="165px" datasizeheight="145px" dataX="0" dataY="1"   alt="image">\
            <img src="./images/62420a8f-ab5e-45c8-82b3-d4e4094f4b79.png" />\
        </div>\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="161px" datasizeheight="146px" dataX="1" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer ie-background commentable non-processed" cx="80.5" cy="73.0" rx="80.5" ry="73.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="80.5" cy="73.0" rx="80.5" ry="73.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="44px" datasizeheight="35px" dataX="19" dataY="280" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">User</span></div></div></div></div>\
      <div id="s-Input_4" class="pie text firer keyup click commentable non-processed"  datasizewidth="291px" datasizeheight="41px" dataX="44" dataY="314" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="94px" datasizeheight="35px" dataX="19" dataY="367" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Password</span></div></div></div></div>\
      <div id="s-Input_5" class="pie password firer click commentable non-processed"  datasizewidth="291px" datasizeheight="41px" dataX="44" dataY="401" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1"  placeholder=""/></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="112px" datasizeheight="57px" dataX="132" dataY="550" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">- Or -</span></div></div></div></div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="78px" datasizeheight="76px" dataX="44" dataY="628"   alt="image">\
          <img src="./images/fd0e85c4-cb9c-4ec6-923f-2b3d71fe61ec.png" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="78px" datasizeheight="76px" dataX="150" dataY="628"   alt="image">\
          <img src="./images/ecd6abc5-b472-4b77-8f7d-b8f58152e682.png" />\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="78px" datasizeheight="76px" dataX="257" dataY="628"   alt="image">\
          <img src="./images/998ca842-ba20-4385-bedb-3e140b37a0a5.png" />\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer ie-background commentable non-processed"   datasizewidth="116px" datasizeheight="51px" dataX="132" dataY="483"  >\
          <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="80px" datasizeheight="35px" dataX="150" dataY="491" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Aceptar</span></div></div></div></div>\
      <div id="s-Rectangle_1" class="pie rectangle firer click ie-background commentable non-processed"   datasizewidth="118px" datasizeheight="52px" dataX="131" dataY="483" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_4" class="pie label singleline firer commentable non-processed"   datasizewidth="263px" datasizeheight="28px" dataX="58" dataY="253" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0"></span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;