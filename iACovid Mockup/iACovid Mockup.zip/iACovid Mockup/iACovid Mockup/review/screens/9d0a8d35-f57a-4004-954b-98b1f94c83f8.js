var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-9d0a8d35-f57a-4004-954b-98b1f94c83f8" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 22" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9d0a8d35-f57a-4004-954b-98b1f94c83f8-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9d0a8d35-f57a-4004-954b-98b1f94c83f8-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9d0a8d35-f57a-4004-954b-98b1f94c83f8-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="35px" dataX="27" dataY="48"   alt="image" systemName="./images/13a00661-8a5f-4f94-b354-e958cb88c93a.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.003 10.998h-19.429l10.104-9.263c.407-.373.435-1.006.062-1.413-.373-.406-1.006-.435-1.413-.062l-12 11-.015.017-.079.09-.051.061-.067.119-.029.055-.052.158-.01.033-.021.205.021.205.01.032.052.16.029.054.067.119.05.061.08.09.015.017 12 11c.191.176.434.263.676.263.27 0 .54-.109.737-.324.373-.407.346-1.039-.062-1.413l-10.104-9.264h19.429c.552 0 1-.447 1-1 0-.552-.448-1-1-1z"/></svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="64px" datasizeheight="35px" dataX="150" dataY="101" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Logros</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="107px" datasizeheight="23px" dataX="27" dataY="204" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Objetivo logrado</span></div></div></div></div>\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="283px" datasizeheight="47px" dataX="15" dataY="237" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="262px" datasizeheight="34px" dataX="20" dataY="242" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Semana de higiene<br />Cumple una semana cumpliendo las normas de higiene</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Image_40" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="315" dataY="242"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="68px" datasizeheight="23px" dataX="15" dataY="364" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Por lograr</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="109px" datasizeheight="23px" dataX="16" dataY="508" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Objetivos diarios</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="62px" datasizeheight="23px" dataX="18" dataY="595" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Faltantes</span></div></div></div></div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="283px" datasizeheight="47px" dataX="15" dataY="297" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="270px" datasizeheight="34px" dataX="20" dataY="302" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Objetos Check<br />Limpia todos los objetos que usas para lograr este logro</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Image_41" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="315" dataY="302"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="283px" datasizeheight="47px" dataX="15" dataY="391"   alt="image">\
          <img src="./images/cde709f5-e24d-4afd-a02b-8ea75b26a300.png" />\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="268px" datasizeheight="34px" dataX="22" dataY="398" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Se vuelve un h&aacute;bito<br />Cumple dos semanas cumpliendo las normas de higiene</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Image_42" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="315" dataY="403"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="283px" datasizeheight="47px" dataX="16" dataY="448"   alt="image">\
          <img src="./images/cde709f5-e24d-4afd-a02b-8ea75b26a300.png" />\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="213px" datasizeheight="34px" dataX="23" dataY="455" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Vu&eacute;lvelo parte de tu vida<br />Limpia tus objetos por una semana completa</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Image_43" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="316" dataY="460"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="283px" datasizeheight="47px" dataX="16" dataY="624"   alt="image">\
          <img src="./images/7fd038cf-2a5a-4d07-b0b9-68f8f0d2b090.png" />\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="226px" datasizeheight="34px" dataX="27" dataY="631" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Lo estas logrando <br />Limpia tus objetos por tres semanas completas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Image_44" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="316" dataY="636"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="339px" datasizeheight="50px" dataX="12" dataY="143" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Al cumplir ciertos logros resivir&aacute;s monedas que te ayudar&aacute;n a conseguir nuevos colores e iconos para la aplicaci&oacute;n. El objetivo te dir&aacute; las monedas ganadas una vez lo hayas completado.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer commentable non-processed"   datasizewidth="330px" datasizeheight="34px" dataX="22" dataY="546" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Haz completado los objetivos del d&iacute;a de hoy, vuelve ma&ntilde;ana para seguir completando y obtener m&aacute;s monedas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="60px" datasizeheight="60px" dataX="289" dataY="691" >\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="60px" datasizeheight="60px" dataX="0" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="30.0" cy="30.0" rx="30.0" ry="30.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="30.0" cy="30.0" rx="30.0" ry="30.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
\
        <div id="s-Image_5" class="pie image firer click ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="45px" dataX="7" dataY="7"   alt="image">\
            <img src="./images/03a06faa-2590-43db-9a14-eed77e804579.png" />\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="246" dataY="706"   alt="image">\
          <img src="./images/fa47430b-85f6-462b-a82d-8b4361a33ff1.png" />\
      </div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="126px" datasizeheight="19px" dataX="110" dataY="711" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Aqu&iacute; esta tu check list.</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;