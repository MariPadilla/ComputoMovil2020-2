var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-4969546d-78e9-4e47-a247-973f212b4a81" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 12" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/4969546d-78e9-4e47-a247-973f212b4a81-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/4969546d-78e9-4e47-a247-973f212b4a81-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/4969546d-78e9-4e47-a247-973f212b4a81-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Image_18" class="pie image firer ie-background commentable non-processed"   datasizewidth="70px" datasizeheight="70px" dataX="152" dataY="95"   alt="image" systemName="./images/96a778cf-4fcc-4863-9a14-c1e7c7df6e28.svg" overlay="#FF0000">\
          <svg preserveAspectRatio=\'none\' id="s-Image_18-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_18 .cls-1{fill:#666;}</style></defs><title>warning</title><path class="cls-1" d="M31,48a3,3,0,1,0-3-3A3,3,0,0,0,31,48Zm0-4a1,1,0,1,1-1,1A1,1,0,0,1,31,44Z"/><path class="cls-1" d="M31,40a3,3,0,0,0,3-3V21a3,3,0,0,0-6,0V37A3,3,0,0,0,31,40ZM30,21a1,1,0,0,1,2,0V37a1,1,0,0,1-2,0V21Z"/><path class="cls-1" d="M9,56H53a7,7,0,0,0,7-7,8.7,8.7,0,0,0-.73-3.11,1,1,0,0,0-.08-0.14L36.75,11l-0.06-.1a7,7,0,0,0-11.38,0l-0.06.1L2.8,45.76s0,0.09-.08.14A8.86,8.86,0,0,0,2,49,7,7,0,0,0,9,56ZM4.53,46.77L27,12a0,0,0,0,1,0,0A5,5,0,0,1,35,12a0,0,0,0,0,0,0L57.47,46.77A6.82,6.82,0,0,1,58,49a5,5,0,0,1-5,5H9a5,5,0,0,1-5-5A6.82,6.82,0,0,1,4.53,46.77Z"/></svg>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="237px" datasizeheight="28px" dataX="68" dataY="171" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">SERVICIOS DE EMERGENCIA</span></div></div></div></div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="334px" datasizeheight="51px" dataX="20" dataY="205" >\
        <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="334px" datasizeheight="51px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_1_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="314px" datasizeheight="36px" dataX="10" dataY="8" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Da click en la imagen del servicio que necesites y la aplicaci&oacute;n te direccionar&aacute; a la llamada.</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="326px" datasizeheight="137px" dataX="24" dataY="268"   alt="image">\
          <img src="./images/b95d9cd2-ee37-4edd-9c00-c5c3facdc23f.jpg" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="326px" datasizeheight="126px" dataX="24" dataY="404"   alt="image">\
          <img src="./images/71c1ba6c-e98f-4089-b3b2-e4ac8ad270a2.jpg" />\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="326px" datasizeheight="126px" dataX="24" dataY="529"   alt="image">\
          <img src="./images/fa58e68e-107d-424e-9573-87a85e4daa36.jpg" />\
      </div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="247px" datasizeheight="95px" dataX="67" dataY="654"   alt="image">\
          <img src="./images/b446ea68-a947-4174-9ba3-201eb9963fbe.jpg" />\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;