var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-253aff73-3ca8-43e2-9730-6a71152a486f" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 14" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/253aff73-3ca8-43e2-9730-6a71152a486f-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/253aff73-3ca8-43e2-9730-6a71152a486f-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/253aff73-3ca8-43e2-9730-6a71152a486f-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="233px" datasizeheight="35px" dataX="70" dataY="163" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Aviso ante los s&iacute;ntomas</span></div></div></div></div>\
\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="328px" datasizeheight="360px" dataX="23" dataY="224" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Aqu&iacute; podr&aacute;s agregar los s&iacute;ntomas que vas teniendo, la aplicaci&oacute;n revisar&aacute; con los s&iacute;ntomas dados por la OMSS y verificar&aacute; si son los indicados. En caso de ser iguales aparecer&aacute; marcado de color verde con una palomita, adem&aacute;s de enviarte una alerta.<br /><br />Las alertas cambiaran con respecto a si fuiste confirmado o no con COVID-19 para que de esta forma continues cuid&aacute;ndote y cuidando a los que quieres.<br /><br />En caso de serlo, la aplicaci&oacute;n te enviar&aacute; un mensaje pidiendo que llames a tu doctor o te ofrecer&aacute; direccionarte a la secci&oacute;n de &quot;Emergencia&quot;.<br /><br />Adem&aacute;s de que en la parte de abajo podr&aacute;s encontrar una lista de hospitales, dando click en la imagen te redireccionar&aacute; al tel&eacute;fono para que realices la llamada.<br /><br />Para cualquier duda sobre los s&iacute;ntomas y otros, verifica la secci&oacute;n de &quot;Informaci&oacute;n&quot;.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="104px" datasizeheight="49px" dataX="135" dataY="619" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0">Aceptar</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;