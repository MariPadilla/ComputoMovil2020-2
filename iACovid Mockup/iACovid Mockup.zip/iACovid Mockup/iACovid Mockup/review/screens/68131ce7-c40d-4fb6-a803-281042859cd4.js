var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-68131ce7-c40d-4fb6-a803-281042859cd4" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 24" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/68131ce7-c40d-4fb6-a803-281042859cd4-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/68131ce7-c40d-4fb6-a803-281042859cd4-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/68131ce7-c40d-4fb6-a803-281042859cd4-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="69px" datasizeheight="35px" dataX="147" dataY="79" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Ajustes</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="105px" datasizeheight="23px" dataX="25" dataY="244" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Aplazar alarma</span></div></div></div></div>\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="308" dataY="242"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_2-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_2 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_2-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="106px" datasizeheight="23px" dataX="25" dataY="285" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Tono de alarma</span></div></div></div></div>\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="308" dataY="283"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_3-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_3 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_3-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="106px" datasizeheight="23px" dataX="25" dataY="324" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Ajustes del chat</span></div></div></div></div>\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="308" dataY="322"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_4-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_4 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_4-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="180px" datasizeheight="23px" dataX="25" dataY="365" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Silenciar autom&aacute;ticamente</span></div></div></div></div>\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="308" dataY="363"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_5-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_5 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_5-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="187px" datasizeheight="23px" dataX="25" dataY="449" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Alerta con tel&eacute;fono apagado</span></div></div></div></div>\
      <div id="s-Image_7" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="307" dataY="499"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_7-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_7 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_7-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="267px" datasizeheight="37px" dataX="25" dataY="494" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Tiempo de alerta<br /></span><span id="rtr-s-Paragraph_1_1">Seleccionar el tiempo previo con el que la alarma sonar&aacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="244px" datasizeheight="55px" dataX="26" dataY="596" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Apple Watch<br /></span><span id="rtr-s-Paragraph_2_1">Seleccione si la aplicaci&oacute;n deber&aacute; enviar la alerta a su Apple Watch.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="190px" datasizeheight="38px" dataX="24" dataY="546" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Apple Watch<br /></span><span id="rtr-s-Paragraph_3_1">Vincular iACovid con Apple Watch</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Toggle-on" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="38px" dataX="283" dataY="546" >\
        <div id="s-Panel_15" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_18" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_18_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_11" class="shapewrapper shapewrapper-s-Ellipse_11 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="26" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_11" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_11)">\
                                  <ellipse id="s-Ellipse_11" class="pie ellipse shape non-processed-shape firer click swipeleft commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_11" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_11" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_11_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_16" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_19" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_19_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_12" class="shapewrapper shapewrapper-s-Ellipse_12 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="8" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_12" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_12)">\
                                  <ellipse id="s-Ellipse_12" class="pie ellipse shape non-processed-shape firer click swiperight commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_12" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_12" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_12_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Toggle-on_1" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="38px" dataX="283" dataY="605" >\
        <div id="s-Panel_17" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_20" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_20_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_13" class="shapewrapper shapewrapper-s-Ellipse_13 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="26" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_13" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_13)">\
                                  <ellipse id="s-Ellipse_13" class="pie ellipse shape non-processed-shape firer click swipeleft commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_13" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_13" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_13_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_18" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_21" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_21_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_14" class="shapewrapper shapewrapper-s-Ellipse_14 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="8" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_14" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_14)">\
                                  <ellipse id="s-Ellipse_14" class="pie ellipse shape non-processed-shape firer click swiperight commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_14" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_14" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_14_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Toggle-on_2" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="38px" dataX="283" dataY="442" >\
        <div id="s-Panel_19" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_22" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_22_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_15" class="shapewrapper shapewrapper-s-Ellipse_15 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="26" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_15" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_15)">\
                                  <ellipse id="s-Ellipse_15" class="pie ellipse shape non-processed-shape firer click swipeleft commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_15" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_15" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_15_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_20" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_23" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_23_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_16" class="shapewrapper shapewrapper-s-Ellipse_16 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="8" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_16" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_16)">\
                                  <ellipse id="s-Ellipse_16" class="pie ellipse shape non-processed-shape firer click swiperight commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_16" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_16" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_16_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="246px" datasizeheight="37px" dataX="25" dataY="669" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Notificar antes de sonar<br /></span><span id="rtr-s-Paragraph_4_1">Mostrar notificaciones antes de que suene la alarma </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Toggle-off" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="38px" dataX="283" dataY="669" >\
        <div id="s-Panel_9" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_14" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_14_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_7" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="26" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_7)">\
                                  <ellipse id="s-Ellipse_7" class="pie ellipse shape non-processed-shape firer click swipeleft commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_7" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_7_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_10" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_15" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_15_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_8" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="8" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_8)">\
                                  <ellipse id="s-Ellipse_8" class="pie ellipse shape non-processed-shape firer click swiperight commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_8" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_8_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="146px" datasizeheight="23px" dataX="20" dataY="735" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Pol&iacute;tica de privacidad</span></div></div></div></div>\
      <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="300" dataY="733"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_8-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_8 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_8-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="136px" datasizeheight="23px" dataX="25" dataY="405" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">Cambiar contrase&ntilde;a</span></div></div></div></div>\
      <div id="s-Image_9" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="307" dataY="403"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_9-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_9 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_9-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_10" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="307" dataY="202"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_10-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_10 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_10-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="313px" datasizeheight="2px" dataX="19" dataY="721" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 313 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="83px" datasizeheight="23px" dataX="25" dataY="125" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">Transiciones</span></div></div></div></div>\
      <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="23px" dataX="25" dataY="163" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">Iconos</span></div></div></div></div>\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="307" dataY="123"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_6-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_6 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_6-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_11" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="307" dataY="161"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_11-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_11 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_11-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="100px" datasizeheight="23px" dataX="26" dataY="204" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">Modo nocturno</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;