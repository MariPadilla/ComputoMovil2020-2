var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-63f22249-8310-4bd7-984c-9ed8f872a8bb" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 25.1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/63f22249-8310-4bd7-984c-9ed8f872a8bb-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/63f22249-8310-4bd7-984c-9ed8f872a8bb-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/63f22249-8310-4bd7-984c-9ed8f872a8bb-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="52px" datasizeheight="35px" dataX="158" dataY="95" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Coins</span></div></div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="304px" datasizeheight="17px" dataX="49" dataY="129" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Al lograr los objetivos puedes conseguir mejoras en la aplicaci&oacute;n </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="165"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="222"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="279"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="336"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="393"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_7" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="450"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="507"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_10" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="564"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
\
      <div id="s-Image_11" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="49" dataY="627"   alt="image">\
          <img src="./images/62e0d3c8-4c01-4ef6-999e-1acad607f1f9.png" />\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="32px" datasizeheight="23px" dataX="182" dataY="178" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Todo</span></div></div></div></div>\
      <div id="s-Text_13" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="34px" datasizeheight="23px" dataX="184" dataY="235" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">Color</span></div></div></div></div>\
      <div id="s-Text_14" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="47px" datasizeheight="23px" dataX="172" dataY="292" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">Ajustes</span></div></div></div></div>\
      <div id="s-Text_15" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="61px" datasizeheight="23px" dataX="170" dataY="349" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_15_0">S&iacute;ntomas</span></div></div></div></div>\
      <div id="s-Text_16" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="36px" datasizeheight="23px" dataX="183" dataY="406" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_16_0">Perfil</span></div></div></div></div>\
      <div id="s-Text_17" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="109px" datasizeheight="23px" dataX="146" dataY="463" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_17_0">Imagen de perfil</span></div></div></div></div>\
      <div id="s-Text_18" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="68px" datasizeheight="23px" dataX="164" dataY="640" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_18_0">Check List</span></div></div></div></div>\
      <div id="s-Text_20" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="49px" datasizeheight="23px" dataX="171" dataY="577" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_20_0">Estatus</span></div></div></div></div>\
      <div id="s-Text_22" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="31px" datasizeheight="23px" dataX="185" dataY="520" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_22_0">Chat</span></div></div></div></div>\
      <div id="s-Image_23" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="176"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_23-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_23 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_23-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_12" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="233"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_12-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_12 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_12-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_13" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="290"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_13-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_13 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_13-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_14" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="347"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_14-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_14 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_14-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_15" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="404"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_15-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_15 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_15-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_16" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="461"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_16-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_16 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_16-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_17" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="518"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_17-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_17 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_17-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_22" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="575"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_22-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_22 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_22-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Image_21" class="pie image firer ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="298" dataY="638"   alt="image" systemName="./images/5a0b17f0-8282-4130-b98c-f69b1f643626.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' id="s-Image_21-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_21 .cls-1{fill:#666;}</style></defs><title>Next111111</title><polygon id="s-Image_21-previous" class="cls-1" points="19.84 8.88 42.97 32 19.84 55.12 17.04 52.26 37.3 32 16.73 11.43 19.84 8.88"/></svg>\
      </div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="45px" datasizeheight="47px" dataX="173" dataY="700" >\
        <div id="s-Image_19" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="45px" dataX="0" dataY="0"   alt="image" systemName="./images/1788a8c1-0e19-4fab-87a2-812f3c136a86.svg" overlay="#434343">\
            <?xml version="1.0" encoding="utf-8"?>\
            <!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
            <svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_19-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
            	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">\
            <path id="s-Image_19-more" fill="#666666" d="M11,38c-2.757,0-5-2.243-5-5s2.243-5,5-5s5,2.243,5,5S13.757,38,11,38z M11,30\
            	c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3s3-1.346,3-3C14,31.346,12.654,30,11,30z M31,38c-2.757,0-5-2.243-5-5s2.243-5,5-5\
            	s5,2.243,5,5S33.757,38,31,38z M31,30c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3c1.654,0,3-1.346,3-3C34,31.346,32.654,30,31,30z\
            	 M51,38c-2.757,0-5-2.243-5-5s2.243-5,5-5s5,2.243,5,5S53.757,38,51,38z M51,30c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3\
            	s3-1.346,3-3C54,31.346,52.654,30,51,30z"/>\
            </svg>\
\
        </div>\
        <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="34px" datasizeheight="20px" dataX="6" dataY="27" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">More</span></div></div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;