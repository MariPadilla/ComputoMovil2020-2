var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-c51fc615-b4c3-47f4-b37e-e44ee275b05f" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 21" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/c51fc615-b4c3-47f4-b37e-e44ee275b05f-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/c51fc615-b4c3-47f4-b37e-e44ee275b05f-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/c51fc615-b4c3-47f4-b37e-e44ee275b05f-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="101px" datasizeheight="35px" dataX="143" dataY="95" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Edit</span><span id="rtr-s-Text_1_1"> Alert</span></div></div></div></div>\
      <div id="s-Category_2" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="93px" datasizeheight="28px" dataX="120" dataY="189"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value">08</div></div><select id="s-Category_2-options" class="s-c51fc615-b4c3-47f4-b37e-e44ee275b05f dropdown-options" ><option  class="option"><br /></option>\
      <option  class="option">01</option>\
      <option  class="option">02</option>\
      <option  class="option">03</option>\
      <option  class="option">04</option>\
      <option  class="option">05</option>\
      <option  class="option">06</option>\
      <option  class="option">07</option>\
      <option selected="selected" class="option">08</option>\
      <option  class="option">09</option>\
      <option  class="option">10</option>\
      <option  class="option">11</option>\
      <option  class="option">12</option></select></div>\
      <div id="s-Button_1" class="pie button singleline firer ie-background commentable non-processed"   datasizewidth="66px" datasizeheight="37px" dataX="43" dataY="153" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0">AM</span></div></div></div></div>\
      <div id="s-Button_2" class="pie button singleline firer ie-background commentable non-processed"   datasizewidth="66px" datasizeheight="37px" dataX="43" dataY="210" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_2_0">PM</span></div></div></div></div>\
      <div id="s-Category_3" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="93px" datasizeheight="28px" dataX="225" dataY="189"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value">00</div></div><select id="s-Category_3-options" class="s-c51fc615-b4c3-47f4-b37e-e44ee275b05f dropdown-options" ><option  class="option"><br /></option>\
      <option  class="option">01</option>\
      <option  class="option">02</option>\
      <option  class="option">03</option>\
      <option  class="option">04</option>\
      <option  class="option">05</option>\
      <option  class="option">06</option>\
      <option  class="option">07</option>\
      <option  class="option">08</option>\
      <option  class="option">09</option>\
      <option  class="option">10</option>\
      <option  class="option">11</option>\
      <option  class="option">12</option>\
      <option  class="option">13</option>\
      <option  class="option">14</option>\
      <option  class="option">15</option>\
      <option  class="option">16</option>\
      <option  class="option">17</option>\
      <option  class="option">18</option>\
      <option  class="option">19</option>\
      <option  class="option">20</option>\
      <option  class="option">21</option>\
      <option  class="option">22</option>\
      <option  class="option">23</option>\
      <option  class="option">24</option>\
      <option  class="option">25</option>\
      <option  class="option">26</option>\
      <option  class="option">27</option>\
      <option  class="option">28</option>\
      <option  class="option">29</option>\
      <option  class="option">30</option>\
      <option  class="option">31</option>\
      <option  class="option">32</option>\
      <option  class="option">33</option>\
      <option  class="option">34</option>\
      <option  class="option">35</option>\
      <option  class="option">36</option>\
      <option  class="option">37</option>\
      <option  class="option">38</option>\
      <option  class="option">39</option>\
      <option  class="option">40</option>\
      <option  class="option">41</option>\
      <option  class="option">42</option>\
      <option  class="option">43</option>\
      <option  class="option">44</option>\
      <option  class="option">45</option>\
      <option  class="option">46</option>\
      <option  class="option">47</option>\
      <option  class="option">48</option>\
      <option  class="option">49</option>\
      <option  class="option">50</option>\
      <option  class="option">51</option>\
      <option  class="option">52</option>\
      <option  class="option">53</option>\
      <option  class="option">54</option>\
      <option  class="option">55</option>\
      <option  class="option">56</option>\
      <option  class="option">57</option>\
      <option  class="option">58</option>\
      <option  class="option">59</option>\
      <option selected="selected" class="option">00</option></select></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="109px" datasizeheight="23px" dataX="21" dataY="273" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Seleccionar tono</span></div></div></div></div>\
      <div id="s-Button_3" class="pie button singleline firer ie-background commentable non-processed"   datasizewidth="138px" datasizeheight="64px" dataX="62" dataY="316" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_3_0">Predeterminada</span></div></div></div></div>\
      <div id="s-Image_19" class="pie image firer ie-background commentable non-processed"   datasizewidth="52px" datasizeheight="52px" dataX="246" dataY="316"   alt="image" systemName="./images/2419f643-64f3-4e92-9b1b-3aa81d8281fb.svg" overlay="#434343">\
          <?xml version="1.0" encoding="utf-8"?>\
          <!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
          <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
          <svg preserveAspectRatio=\'none\' version="1.1" id="s-Image_19-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
          	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">\
          <path id="s-Image_19-more" fill="#666666" d="M11,38c-2.757,0-5-2.243-5-5s2.243-5,5-5s5,2.243,5,5S13.757,38,11,38z M11,30\
          	c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3s3-1.346,3-3C14,31.346,12.654,30,11,30z M31,38c-2.757,0-5-2.243-5-5s2.243-5,5-5\
          	s5,2.243,5,5S33.757,38,31,38z M31,30c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3c1.654,0,3-1.346,3-3C34,31.346,32.654,30,31,30z\
          	 M51,38c-2.757,0-5-2.243-5-5s2.243-5,5-5s5,2.243,5,5S53.757,38,51,38z M51,30c-1.654,0-3,1.346-3,3c0,1.654,1.346,3,3,3\
          	s3-1.346,3-3C54,31.346,52.654,30,51,30z"/>\
          </svg>\
\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="29px" datasizeheight="18px" dataX="257" dataY="367" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">More</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="48px" datasizeheight="23px" dataX="21" dataY="409" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Repetir</span></div></div></div></div>\
      <div id="s-Category_4" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="93px" datasizeheight="28px" dataX="247" dataY="407"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value"></div></div><select id="s-Category_4-options" class="s-c51fc615-b4c3-47f4-b37e-e44ee275b05f dropdown-options" ><option selected="selected" class="option"><br /></option>\
      <option  class="option">Una vez</option>\
      <option  class="option">Diaramente</option>\
      <option  class="option">De lun a vie</option>\
      <option  class="option">Personalizar</option></select></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="172px" datasizeheight="23px" dataX="21" dataY="467" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Vibrar al sonar la alarma</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="223px" datasizeheight="23px" dataX="19" dataY="520" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Eliminar cuando suene la alarma</span></div></div></div></div>\
      <div id="s-Toggle-on" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="38px" dataX="273" dataY="470" >\
        <div id="s-Panel_15" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_18" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_18_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_11" class="shapewrapper shapewrapper-s-Ellipse_11 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="26" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_11" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_11)">\
                                  <ellipse id="s-Ellipse_11" class="pie ellipse shape non-processed-shape firer click swipeleft commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_11" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_11" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_11_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_16" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_19" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_19_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_12" class="shapewrapper shapewrapper-s-Ellipse_12 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="8" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_12" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_12)">\
                                  <ellipse id="s-Ellipse_12" class="pie ellipse shape non-processed-shape firer click swiperight commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_12" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_12" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_12_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Toggle-on_1" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="62px" datasizeheight="38px" dataX="273" dataY="513" >\
        <div id="s-Panel_17" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_20" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_20_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_13" class="shapewrapper shapewrapper-s-Ellipse_13 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="26" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_13" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_13)">\
                                  <ellipse id="s-Ellipse_13" class="pie ellipse shape non-processed-shape firer click swipeleft commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_13" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_13" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_13_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
        <div id="s-Panel_18" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="62px" datasizeheight="38px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="s-Rectangle_21" class="pie rectangle firer commentable non-processed"   datasizewidth="49px" datasizeheight="32px" dataX="8" dataY="3" >\
               <div class="backgroundLayer"></div>\
               <div class="paddingLayer">\
                 <div class="clipping">\
                   <div class="content">\
                     <div class="valign">\
                       <span id="rtr-s-Rectangle_21_0"></span>\
                     </div>\
                   </div>\
                 </div>\
               </div>\
              </div>\
              <div id="shapewrapper-s-Ellipse_14" class="shapewrapper shapewrapper-s-Ellipse_14 non-processed"   datasizewidth="30px" datasizeheight="30px" dataX="8" dataY="4" >\
                  <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_14" class="svgContainer" style="width:100%; height:100%;">\
                      <g>\
                          <g clip-path="url(#clip-s-Ellipse_14)">\
                                  <ellipse id="s-Ellipse_14" class="pie ellipse shape non-processed-shape firer click swiperight commentable non-processed" cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </g>\
                      </g>\
                      <defs>\
                          <clipPath id="clip-s-Ellipse_14" class="clipPath">\
                                  <ellipse cx="15.0" cy="15.0" rx="15.0" ry="15.0">\
                                  </ellipse>\
                          </clipPath>\
                      </defs>\
                  </svg>\
                  <div class="shapert-clipping">\
                      <div id="shapert-s-Ellipse_14" class="content firer" >\
                          <div class="valign">\
                              <span id="rtr-s-Ellipse_14_0"></span>\
                          </div>\
                      </div>\
                  </div>\
              </div>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="64px" datasizeheight="23px" dataX="21" dataY="567" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Actividad</span></div></div></div></div>\
      <div id="s-Input_1" class="pie text firer keyup commentable non-processed"  datasizewidth="234px" datasizeheight="20px" dataX="101" dataY="569" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Category_5" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="93px" datasizeheight="28px" dataX="241" dataY="610"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value"></div></div><select id="s-Category_5-options" class="s-c51fc615-b4c3-47f4-b37e-e44ee275b05f dropdown-options" ><option selected="selected" class="option"><br /></option>\
      <option  class="option">Azul</option>\
      <option  class="option">Verde</option>\
      <option  class="option">Amarillo</option>\
      <option  class="option">Rosa</option></select></div>\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="35px" dataX="27" dataY="48"   alt="image" systemName="./images/13a00661-8a5f-4f94-b354-e958cb88c93a.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.003 10.998h-19.429l10.104-9.263c.407-.373.435-1.006.062-1.413-.373-.406-1.006-.435-1.413-.062l-12 11-.015.017-.079.09-.051.061-.067.119-.029.055-.052.158-.01.033-.021.205.021.205.01.032.052.16.029.054.067.119.05.061.08.09.015.017 12 11c.191.176.434.263.676.263.27 0 .54-.109.737-.324.373-.407.346-1.039-.062-1.413l-10.104-9.264h19.429c.552 0 1-.447 1-1 0-.552-.448-1-1-1z"/></svg>\
      </div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="44px" datasizeheight="23px" dataX="19" dataY="657" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">Sonar </span></div></div></div></div>\
      <div id="s-Category_6" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="93px" datasizeheight="28px" dataX="241" dataY="655"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value"></div></div><select id="s-Category_6-options" class="s-c51fc615-b4c3-47f4-b37e-e44ee275b05f dropdown-options" ><option selected="selected" class="option"><br /></option>\
      <option  class="option">10 min. antes</option>\
      <option  class="option">20 min. antes</option>\
      <option  class="option">5 min. antes</option>\
      <option  class="option">25 min. antes</option></select></div>\
      <div id="s-Image_40" class="pie image firer click ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="155" dataY="696"   alt="image" systemName="./images/39b92206-c0ef-4c76-a68a-289733fce9ae.svg" overlay="#434343">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="184px" datasizeheight="19px" dataX="19" dataY="614" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">Color de la notificaci&oacute;n de alarma</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;