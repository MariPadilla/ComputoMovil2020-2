var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-434b979c-2d8b-4683-90ec-199ca564ecb9" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 18.1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/434b979c-2d8b-4683-90ec-199ca564ecb9-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/434b979c-2d8b-4683-90ec-199ca564ecb9-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/434b979c-2d8b-4683-90ec-199ca564ecb9-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="101px" datasizeheight="35px" dataX="143" dataY="95" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">S&iacute;ntomas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="334px" datasizeheight="162px" dataX="27" dataY="380" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Los coronavirus son una extensa familia de virus que pueden causar enfermedades tanto en animales como en humanos. En los humanos, se sabe que varios coronavirus causan infecciones respiratorias que pueden ir desde el resfriado com&uacute;n hasta enfermedades m&aacute;s graves como el s&iacute;ndrome respiratorio de Oriente Medio (MERS) y el s&iacute;ndrome respiratorio agudo severo (SRAS). El coronavirus que se ha descubierto m&aacute;s recientemente causa la enfermedad por coronavirus COVID-19.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="118px" datasizeheight="23px" dataX="80" dataY="680" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">P&aacute;gina de la OMS</span></div></div></div></div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="63px" datasizeheight="58px" dataX="235" dataY="663"   alt="image">\
          <img src="./images/eb8eb47a-9336-4834-8f86-cc4cf910e5cc.png" />\
      </div>\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="35px" dataX="27" dataY="48"   alt="image" systemName="./images/13a00661-8a5f-4f94-b354-e958cb88c93a.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.003 10.998h-19.429l10.104-9.263c.407-.373.435-1.006.062-1.413-.373-.406-1.006-.435-1.413-.062l-12 11-.015.017-.079.09-.051.061-.067.119-.029.055-.052.158-.01.033-.021.205.021.205.01.032.052.16.029.054.067.119.05.061.08.09.015.017 12 11c.191.176.434.263.676.263.27 0 .54-.109.737-.324.373-.407.346-1.039-.062-1.413l-10.104-9.264h19.429c.552 0 1-.447 1-1 0-.552-.448-1-1-1z"/></svg>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="317px" datasizeheight="181px" dataX="35" dataY="180"   alt="image">\
          <img src="./images/8533b03f-edfb-4a6f-ac1b-007c5377eaee.jpg" />\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;