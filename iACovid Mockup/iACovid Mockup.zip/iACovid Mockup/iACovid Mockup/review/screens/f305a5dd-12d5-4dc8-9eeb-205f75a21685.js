var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-f305a5dd-12d5-4dc8-9eeb-205f75a21685" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 0" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/f305a5dd-12d5-4dc8-9eeb-205f75a21685-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/f305a5dd-12d5-4dc8-9eeb-205f75a21685-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/f305a5dd-12d5-4dc8-9eeb-205f75a21685-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer pageload ie-background commentable non-processed"   datasizewidth="375px" datasizeheight="812px" dataX="0" dataY="0"   alt="image">\
          <img src="./images/3b3be8cc-41e3-40af-a6b8-9f2906a5fed7.jpeg" />\
      </div>\
      <div id="s-Button_1" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="199px" datasizeheight="142px" dataX="96" dataY="351" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0"></span></div></div></div></div>\
      <div id="s-Text_1" class="pie label singleline firer ie-background commentable non-processed"   datasizewidth="215px" datasizeheight="27px" dataX="88" dataY="340" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0"></span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;