var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="358px" datasizeheight="57px" dataX="13" dataY="217" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">We are here for you! </span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="274px" datasizeheight="57px" dataX="55" dataY="154" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Hey! Let&#039;s Start!</span></div></div></div></div>\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="175px" datasizeheight="153px" dataX="104" dataY="285" >\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="175px" datasizeheight="152px" dataX="0" dataY="1"   alt="image">\
            <img src="./images/62420a8f-ab5e-45c8-82b3-d4e4094f4b79.png" />\
        </div>\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="171px" datasizeheight="153px" dataX="2" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer ie-background commentable non-processed" cx="85.5" cy="76.5" rx="85.5" ry="76.5">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="85.5" cy="76.5" rx="85.5" ry="76.5">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="312px" datasizeheight="70px" dataX="35" dataY="494" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_1_0">Register</span></div></div></div></div>\
      <div id="s-Button_2" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="312px" datasizeheight="70px" dataX="36" dataY="597" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_2_0">Sign In</span></div></div></div></div>\
      <div id="s-Dynamic_Panel_1" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="0px" datasizeheight="0px" dataX="54" dataY="751" >\
        <div id="s-Panel_1" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="0px" datasizeheight="0px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
          </div>\
        </div>\
        <div id="s-Panel_2" class="pie panel hidden firer ie-background commentable non-processed"  datasizewidth="0px" datasizeheight="0px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
          </div>\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;