var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-a912af55-b5a7-4b47-8e4b-c36b451d40b4" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 6" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a912af55-b5a7-4b47-8e4b-c36b451d40b4-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/a912af55-b5a7-4b47-8e4b-c36b451d40b4-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/a912af55-b5a7-4b47-8e4b-c36b451d40b4-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="127px" datasizeheight="126px" dataX="124" dataY="116" >\
        <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="127px" datasizeheight="126px" dataX="0" dataY="0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                <g>\
                    <g clip-path="url(#clip-s-Ellipse_1)">\
                            <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="63.5" cy="63.0" rx="63.5" ry="63.0">\
                            </ellipse>\
                    </g>\
                </g>\
                <defs>\
                    <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                            <ellipse cx="63.5" cy="63.0" rx="63.5" ry="63.0">\
                            </ellipse>\
                    </clipPath>\
                </defs>\
            </svg>\
            <div class="shapert-clipping">\
                <div id="shapert-s-Ellipse_1" class="content firer" >\
                    <div class="valign">\
                        <span id="rtr-s-Ellipse_1_0"></span>\
                    </div>\
                </div>\
            </div>\
        </div>\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="79px" datasizeheight="71px" dataX="24" dataY="27"   alt="image" systemName="./images/ab2343aa-ea8f-4027-b0f1-2bd2a21ac70e.svg" overlay="#000000">\
            <svg preserveAspectRatio=\'none\' id="s-Image_1-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_1 .cls-1{fill:#666;}</style></defs><title>user_2</title><path id="s-Image_1-user_2" class="cls-1" d="M36.7,32.66a13,13,0,1,0-11.41,0A25,25,0,0,0,6,57a1,1,0,0,0,2,0,23,23,0,0,1,46,0,1,1,0,0,0,2,0A25,25,0,0,0,36.7,32.66ZM20,21A11,11,0,1,1,31,32,11,11,0,0,1,20,21Z"/></svg>\
        </div>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="163px" datasizeheight="35px" dataX="13" dataY="401" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Compartir por...</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="205px" datasizeheight="30px" dataX="13" dataY="287" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">&iquest;Qu&eacute; deseas compartir?</span></div></div></div></div>\
      <div id="s-Category_2" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="180px" datasizeheight="28px" dataX="93" dataY="339"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value">Estatus</div></div><select id="s-Category_2-options" class="s-a912af55-b5a7-4b47-8e4b-c36b451d40b4 dropdown-options" ><option  class="option"><br /></option>\
      <option  class="option">Logros</option>\
      <option  class="option">Check List</option>\
      <option  class="option">Informaci&oacute;n</option>\
      <option selected="selected" class="option">Estatus</option></select></div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="44" dataY="471"   alt="image">\
          <img src="./images/fd0e85c4-cb9c-4ec6-923f-2b3d71fe61ec.png" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="51px" dataX="43" dataY="535"   alt="image">\
          <img src="./images/ecd6abc5-b472-4b77-8f7d-b8f58152e682.png" />\
      </div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="53px" datasizeheight="53px" dataX="41" dataY="667"   alt="image">\
          <img src="./images/0b051738-efd8-4fd8-8dec-e91bebd3e0ec.png" />\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="50px" dataX="163" dataY="471"   alt="image">\
          <img src="./images/622beb3f-bc7e-4287-a742-cb9ae799789e.png" />\
      </div>\
\
      <div id="s-Image_7" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="45px" dataX="165" dataY="538"   alt="image">\
          <img src="./images/d4065730-9001-4aa9-b8f3-efc13a6c295f.png" />\
      </div>\
\
      <div id="s-Image_8" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="45px" dataX="165" dataY="604"   alt="image">\
          <img src="./images/bfe90c2f-ebc0-4676-85d1-ecc8a26ebebf.png" />\
      </div>\
\
      <div id="s-Image_9" class="pie image firer ie-background commentable non-processed"   datasizewidth="65px" datasizeheight="65px" dataX="155" dataY="661"   alt="image">\
          <img src="./images/292f51bb-09ab-447d-98ca-471a52e1afb4.png" />\
      </div>\
\
      <div id="s-Image_10" class="pie image firer ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="43px" dataX="274" dataY="474"   alt="image">\
          <img src="./images/b156d477-e0d1-4d58-bfc4-eba19875f31b.png" />\
      </div>\
\
      <div id="s-Image_11" class="pie image firer ie-background commentable non-processed"   datasizewidth="53px" datasizeheight="53px" dataX="269" dataY="534"   alt="image">\
          <img src="./images/a2f2cd83-2c51-4ab6-beea-22e90837e0eb.png" />\
      </div>\
\
      <div id="s-Image_12" class="pie image firer ie-background commentable non-processed"   datasizewidth="37px" datasizeheight="37px" dataX="49" dataY="608"   alt="image">\
          <img src="./images/239e0092-aeaf-4d34-b1fe-af3d49b18b4d.png" />\
      </div>\
      <div id="s-Group_11" class="group firer ie-background commentable non-processed" datasizewidth="57px" datasizeheight="57px" dataX="267" dataY="598" >\
        <div id="s-Button_5" class="pie button singleline firer ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="57px" dataX="0" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_5_0"></span></div></div></div></div>\
        <div id="s-Image_13" class="pie image firer ie-background commentable non-processed"   datasizewidth="45px" datasizeheight="45px" dataX="6" dataY="6"   alt="image" systemName="./images/e4134670-666e-439c-914e-81ab221fb689.svg" overlay="#A9A9A9">\
            <svg preserveAspectRatio=\'none\' id="s-Image_13-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_13 .cls-1{fill:#666;}</style></defs><title>bluetooth-01 2</title><path id="s-Image_13-bluetooth" class="cls-1" d="M31,60.6a1.29,1.29,0,0,1-1.3-1.3V35.51L16.26,47.21a1.3,1.3,0,1,1-1.72-2L29.7,32h0L14.54,18.68a1.3,1.3,0,1,1,1.72-2h0L29.7,28.49V4.7a1.3,1.3,0,0,1,2.18-1L47.48,18a1.3,1.3,0,0,1,.1,1.84l-0.1.1L33.72,32,47.46,44a1.3,1.3,0,0,1,.1,1.84l-0.1.1-15.6,14.3A1.3,1.3,0,0,1,31,60.6Zm1.3-26.39v22.1L44.65,45Zm0-26.56v22.1L44.65,19Z"/></svg>\
        </div>\
      </div>\
\
      <div id="s-Image_14" class="pie image firer ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="276" dataY="674"   alt="image">\
          <img src="./images/5e15d677-9024-4fa6-88d0-42ac550af82b.png" />\
      </div>\
\
      <div id="s-Image_15" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="50px" dataX="295" dataY="46"   alt="image">\
          <img src="./images/66756881-8d0b-46f5-8c09-35c2b1cc6b45.png" />\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;