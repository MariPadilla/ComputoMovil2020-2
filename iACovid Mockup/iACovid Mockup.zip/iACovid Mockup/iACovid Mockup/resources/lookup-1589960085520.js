(function(window, undefined) {
  var dictionary = {
    "a8d1bfcf-e065-403e-9b7c-957c793c6300": "Screen 19",
    "b9d3e1c7-98a9-4294-9667-3eb076358f22": "Screen 18",
    "e76cc449-c950-4cb7-926f-29ace102db3e": "Screen 17",
    "eaf77700-dcce-46f0-afeb-6ed29bfa6daf": "Screen 16",
    "89eb57bb-2700-4d99-b18f-26da6c7f0d30": "Screen 15",
    "253aff73-3ca8-43e2-9730-6a71152a486f": "Screen 14",
    "57b4c937-8604-4aa0-91f3-5c565a4ac1af": "Screen 13",
    "4969546d-78e9-4e47-a247-973f212b4a81": "Screen 12",
    "a8106634-1a2d-4341-acb7-8587eaf2e38d": "Screen 11",
    "3447245b-fa1e-4c7c-a504-d6878c155f98": "Screen 10",
    "434b979c-2d8b-4683-90ec-199ca564ecb9": "Screen 18.1",
    "397beb8d-ffb0-4c3a-8856-f8a31878ae04": "Screen 9",
    "baf14e36-4450-4273-9242-bb57348ac5e3": "Screen 8",
    "23fd3a3e-8938-47d7-961e-d751cfa93711": "Screen 7",
    "a912af55-b5a7-4b47-8e4b-c36b451d40b4": "Screen 6",
    "1f332b31-31df-4f68-b2b1-7d1d471bf4e1": "Screen 25",
    "41f0b415-c70a-4de2-8e93-e2ce42598061": "Screen 4.9.2",
    "fb4ebeae-3587-4e80-b3ce-90c09cebe25c": "Screen 4.9.1",
    "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f": "Screen 5",
    "68131ce7-c40d-4fb6-a803-281042859cd4": "Screen 24",
    "fb3c4a56-004c-48e3-9128-dd545a1e7a9b": "Screen 4",
    "294abed7-be54-4cca-8dc0-82d4935425f7": "Screen 23",
    "9d0a8d35-f57a-4004-954b-98b1f94c83f8": "Screen 22",
    "2c6c00ca-dcc8-4998-abb3-4d811fbbe95a": "Screen 3",
    "c51fc615-b4c3-47f4-b37e-e44ee275b05f": "Screen 21",
    "2bae273d-ad8f-4f4d-96c0-48a3ad5b87c4": "Screen 2",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "69ac48ba-f9cd-4fcf-8cfb-91311063d95b": "Screen 20",
    "f305a5dd-12d5-4dc8-9eeb-205f75a21685": "Screen 0",
    "6e60f637-1442-4dc5-8fcd-bb04d8bfe4cd": "Screen 4.9",
    "63f22249-8310-4bd7-984c-9ed8f872a8bb": "Screen 25.1",
    "7c7dd059-91db-459e-8ecc-460fed6e7f44": "Notificacion Screen",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);