var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-89eb57bb-2700-4d99-b18f-26da6c7f0d30" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 15" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/89eb57bb-2700-4d99-b18f-26da6c7f0d30-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/89eb57bb-2700-4d99-b18f-26da6c7f0d30-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/89eb57bb-2700-4d99-b18f-26da6c7f0d30-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="72px" datasizeheight="35px" dataX="144" dataY="95" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Estatus</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="127px" datasizeheight="23px" dataX="25" dataY="129" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Selecciona tu pa&iacute;s...</span></div></div></div></div>\
      <div id="s-Category_2" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="257px" datasizeheight="28px" dataX="54" dataY="159"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value">Mundo</div></div><select id="s-Category_2-options" class="s-89eb57bb-2700-4d99-b18f-26da6c7f0d30 dropdown-options" ><option  class="option"><br /></option>\
      <option  class="option">Estados Unidos</option>\
      <option  class="option">Alemania</option>\
      <option  class="option">M&eacute;xico</option>\
      <option  class="option">Espa&ntilde;a</option>\
      <option  class="option">Jap&oacute;n</option>\
      <option  class="option">Argelia</option>\
      <option  class="option">Corea del Norte</option>\
      <option  class="option">Corea del Sur</option>\
      <option selected="selected" class="option">Mundo</option></select></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="136px" datasizeheight="23px" dataX="19" dataY="202" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Selecciona el estatus</span></div></div></div></div>\
      <div id="s-Category_3" class="inputIOS nativedropdown firer ie-background commentable non-processed"    datasizewidth="257px" datasizeheight="28px" dataX="54" dataY="236"  tabindex="-1"><div class="backgroundLayer"><div class="icon"></div></div><div class="valign"><div class="value">Todo</div></div><select id="s-Category_3-options" class="s-89eb57bb-2700-4d99-b18f-26da6c7f0d30 dropdown-options" ><option  class="option"><br /></option>\
      <option  class="option">Infectados</option>\
      <option  class="option">Muertes</option>\
      <option  class="option">Curados</option>\
      <option selected="selected" class="option">Todo</option></select></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="327px" datasizeheight="54px" dataX="23" dataY="276" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Al seleccionar uno de los estatus se mostrar&aacute; las cifras de dicho estatus y una gr&aacute;fica correspondiente reportadas hasta el d&iacute;a actual.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="pie label singleline firer commentable non-processed"   datasizewidth="121px" datasizeheight="42px" dataX="53" dataY="362" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Confirmados</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline firer commentable non-processed"   datasizewidth="121px" datasizeheight="42px" dataX="53" dataY="412" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Recuperados</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline firer commentable non-processed"   datasizewidth="121px" datasizeheight="42px" dataX="53" dataY="463" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Muertos</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="68px" datasizeheight="35px" dataX="230" dataY="365" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">3.3 M</span></div></div></div></div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="83px" datasizeheight="35px" dataX="222" dataY="415" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">1.04 M</span></div></div></div></div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="69px" datasizeheight="35px" dataX="229" dataY="466" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">235 K</span></div></div></div></div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="58px" datasizeheight="18px" dataX="19" dataY="339" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">M = mill&oacute;n</span></div></div></div></div>\
      <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="38px" datasizeheight="18px" dataX="89" dataY="339" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">K = mil</span></div></div></div></div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="360px" datasizeheight="222px" dataX="7" dataY="514"   alt="image">\
          <img src="./images/5f6b5e7b-5018-47c3-8a36-e816e1b59138.png" />\
      </div>\
      <div id="s-Text_12" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="347px" datasizeheight="16px" dataX="6" dataY="744" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">Da click en la p&aacute;gina para ir al sitio donde se obtiene la gr&aacute;fica...</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;