var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-eaf77700-dcce-46f0-afeb-6ed29bfa6daf" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 16" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/eaf77700-dcce-46f0-afeb-6ed29bfa6daf-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/eaf77700-dcce-46f0-afeb-6ed29bfa6daf-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/eaf77700-dcce-46f0-afeb-6ed29bfa6daf-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="93px" datasizeheight="35px" dataX="133" dataY="108" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">S&iacute;ntomas</span></div></div></div></div>\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="35px" dataX="27" dataY="48"   alt="image" systemName="./images/13a00661-8a5f-4f94-b354-e958cb88c93a.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.003 10.998h-19.429l10.104-9.263c.407-.373.435-1.006.062-1.413-.373-.406-1.006-.435-1.413-.062l-12 11-.015.017-.079.09-.051.061-.067.119-.029.055-.052.158-.01.033-.021.205.021.205.01.032.052.16.029.054.067.119.05.061.08.09.015.017 12 11c.191.176.434.263.676.263.27 0 .54-.109.737-.324.373-.407.346-1.039-.062-1.413l-10.104-9.264h19.429c.552 0 1-.447 1-1 0-.552-.448-1-1-1z"/></svg>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="134px" datasizeheight="23px" dataX="27" dataY="151" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Ingresa</span><span id="rtr-s-Text_2_1"> tu s&iacute;ntoma...</span></div></div></div></div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed"  datasizewidth="238px" datasizeheight="22px" dataX="47" dataY="191" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed"  datasizewidth="238px" datasizeheight="22px" dataX="47" dataY="222" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed"  datasizewidth="238px" datasizeheight="22px" dataX="47" dataY="253" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed"  datasizewidth="238px" datasizeheight="22px" dataX="47" dataY="288" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Image_34" class="pie image firer ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="146" dataY="339"   alt="image" systemName="./images/06f2128d-00db-476c-9fca-2260c5488514.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19.646 3.384c-2.167-2.177-5.052-3.378-8.147-3.384-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.499-11.479.006-3.071-1.185-5.961-3.353-8.137zm-8.146 19.116zm5.999-10.488l-5.5-.006v5.494c0 .276-.225.5-.5.5-.276 0-.5-.224-.5-.5v-5.495l-5.501-.005c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l5.5.005v-5.505c0-.276.224-.5.5-.5.275 0 .5.224.5.5v5.506l5.501.006c.275 0 .5.224.499.5 0 .276-.224.5-.5.5z"/></svg>\
      </div>\
      <div id="s-Image_40" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="316" dataY="190"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Image_41" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="316" dataY="221"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Image_42" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="316" dataY="252"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Image_43" class="pie image firer ie-background commentable non-processed"   datasizewidth="24px" datasizeheight="24px" dataX="316" dataY="287"   alt="image" systemName="./images/461441a2-e16a-46e1-a54f-14b0e6ab1788.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' version="1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g><path d="M16.659 8.134l-7.146 6.67-2.159-2.158c-.195-.195-.512-.195-.707 0s-.195.512 0 .707l2.5 2.5c.097.098.225.147.353.147.123 0 .245-.045.341-.134l7.5-7c.202-.188.212-.505.024-.707-.189-.202-.503-.213-.706-.025zM12 0c-6.617 0-12 5.383-12 12s5.383 12 12 12 12-5.383 12-12-5.383-12-12-12zm0 23c-6.065 0-11-4.935-11-11s4.935-11 11-11 11 4.935 11 11-4.935 11-11 11z"/></g></svg>\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="131px" datasizeheight="23px" dataX="28" dataY="405" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Lista de hospitales...</span></div></div></div></div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="158px" datasizeheight="75px" dataX="28" dataY="440"   alt="image">\
          <img src="./images/e4392c11-4fe0-480c-a303-d337bdd321b2.jpg" />\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="144px" datasizeheight="75px" dataX="213" dataY="440"   alt="image">\
          <img src="./images/0543e090-0210-42bf-8c36-0e12ff73c7ca.jpg" />\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="156px" datasizeheight="89px" dataX="30" dataY="543"   alt="image">\
          <img src="./images/08b52148-4c22-4a7a-abbf-ca849db5532c.jpg" />\
      </div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="154px" datasizeheight="89px" dataX="203" dataY="543"   alt="image">\
          <img src="./images/842e20a5-2d91-4b58-8b42-4de2a7f37acc.png" />\
      </div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="117px" datasizeheight="23px" dataX="20" dataY="656" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Mensaje iACovid...</span></div></div></div></div>\
      <div id="shapewrapper-s-Callout_1" class="shapewrapper shapewrapper-s-Callout_1 non-processed"   datasizewidth="334px" datasizeheight="81px" dataX="28" dataY="684" originalwidth="334px" originalheight="81px" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Callout_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Callout_1)">\
                          <path id="s-Callout_1" class="pie callout shape non-processed-shape firer commentable non-processed" d="M 0 0 L 0 72 L 66 72 L 66 81 L 88 72 L 334 72 L 334 0 Z">\
                          </path>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Callout_1" class="clipPath">\
                          <path d="M 0 0 L 0 72 L 66 72 L 66 81 L 88 72 L 334 72 L 334 0 Z">\
                          </path>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="shapert-clipping">\
              <div id="shapert-s-Callout_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Callout_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="272px" datasizeheight="36px" dataX="85" dataY="697" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Recuerda mantener la calma. Todo mejorar&aacute;<br />Nosotros estamos aqu&iacute; para ayudarte.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="38" dataY="695"   alt="image">\
          <img src="./images/cd62aac7-34e5-4780-8cd4-daf293509863.png" />\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;