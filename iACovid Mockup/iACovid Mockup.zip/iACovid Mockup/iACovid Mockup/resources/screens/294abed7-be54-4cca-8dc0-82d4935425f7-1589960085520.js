jQuery("#simulation")
  .on("click", ".s-294abed7-be54-4cca-8dc0-82d4935425f7 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Image_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f",
                    "transition": {
                      "type": "slideright",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/9d0a8d35-f57a-4004-954b-98b1f94c83f8",
                    "transition": {
                      "type": "slideright",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_40")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_4",
                    "property": "jimGetValue"
                  },{
                    "datatype": "property",
                    "target": "#s-Input_5",
                    "property": "jimGetValue"
                  } ]
                },{
                  "action": "jimAnd",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_6",
                    "property": "jimGetValue"
                  },{
                    "action": "jimAnd",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_7",
                      "property": "jimGetValue"
                    },{
                      "action": "jimAnd",
                      "parameter": [ {
                        "datatype": "property",
                        "target": "#s-Input_8",
                        "property": "jimGetValue"
                      },{
                        "action": "jimAnd",
                        "parameter": [ {
                          "action": "jimAnd",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Input_9",
                            "property": "jimGetValue"
                          },{
                            "datatype": "property",
                            "target": "#s-Input_10",
                            "property": "jimGetValue"
                          } ]
                        },{
                          "action": "jimAnd",
                          "parameter": [ {
                            "datatype": "property",
                            "target": "#s-Input_11",
                            "property": "jimGetValue"
                          },{
                            "action": "jimAnd",
                            "parameter": [ {
                              "datatype": "property",
                              "target": "#s-Input_12",
                              "property": "jimGetValue"
                            },{
                              "action": "jimEquals",
                              "parameter": [ {
                                "action": "jimAnd",
                                "parameter": [ {
                                  "datatype": "property",
                                  "target": "#s-Input_13",
                                  "property": "jimGetValue"
                                },{
                                  "action": "jimAnd",
                                  "parameter": [ {
                                    "datatype": "property",
                                    "target": "#s-Input_14",
                                    "property": "jimGetValue"
                                  },{
                                    "datatype": "property",
                                    "target": "#s-Input_15",
                                    "property": "jimGetValue"
                                  } ]
                                } ]
                              },{
                                "datatype": "variable",
                                "element": "Listo"
                              } ]
                            } ]
                          } ]
                        } ]
                      } ]
                    } ]
                  } ]
                } ]
              },
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/9d0a8d35-f57a-4004-954b-98b1f94c83f8",
                    "transition": {
                      "type": "slideleft",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("variablechange.jim", ".s-294abed7-be54-4cca-8dc0-82d4935425f7 .variablechange", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Image_40")) {
      cases = [
        {
          "blocks": [
            {
              "condition": (data.variableTarget === "Listo") && {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Image_40",
                  "property": "jimIsVisible"
                },{
                  "datatype": "variable",
                  "element": "Listo"
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-294abed7-be54-4cca-8dc0-82d4935425f7 #s-Image_40 > svg": {
                      "attributes": {
                        "overlay": "#B9FFB9"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });