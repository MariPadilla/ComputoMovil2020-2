var content='<div class="ui-page" deviceName="iPhoneX" deviceType="mobile" deviceWidth="375" deviceHeight="812">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1589960085520-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b9d3e1c7-98a9-4294-9667-3eb076358f22" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 18" width="375" height="812">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b9d3e1c7-98a9-4294-9667-3eb076358f22-1589960085520.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/b9d3e1c7-98a9-4294-9667-3eb076358f22-1589960085520-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/b9d3e1c7-98a9-4294-9667-3eb076358f22-1589960085520-ie8.css" /><![endif]-->\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="55px" dataX="297" dataY="41"   alt="image">\
          <img src="./images/854c63e0-d7a9-478b-92fe-031f1870372a.png" />\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="101px" datasizeheight="35px" dataX="143" dataY="95" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">S&iacute;ntomas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="334px" datasizeheight="360px" dataX="23" dataY="325" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Los s&iacute;ntomas m&aacute;s comunes de la COVID‑19 son fiebre, tos seca y cansancio. Algunos pacientes pueden presentar dolores, congesti&oacute;n nasal, dolor de garganta o diarrea. Estos s&iacute;ntomas suelen ser leves y aparecen de forma gradual. Algunas personas se infectan pero solo presentan s&iacute;ntomas muy leves. La mayor&iacute;a de las personas (alrededor del 80%) se recuperan de la enfermedad sin necesidad de tratamiento hospitalario. Alrededor de 1 de cada 5 personas que contraen la COVID‑19 desarrolla una enfermedad grave y tiene dificultad para respirar. Las personas mayores y las que padecen afecciones m&eacute;dicas subyacentes, como hipertensi&oacute;n arterial, problemas cardiacos o pulmonares, diabetes o c&aacute;ncer tienen m&aacute;s probabilidades de desarrollar una enfermedad grave. Sin embargo, cualquier persona puede contraer la COVID‑19 y desarrollar una enfermedad grave. Incluso las personas con s&iacute;ntomas muy leves de COVID‑19 pueden transmitir el virus. Las personas de todas las edades que tengan fiebre, tos y dificultad para respirar deben buscar atenci&oacute;n m&eacute;dica.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="322px" datasizeheight="172px" dataX="29" dataY="136"   alt="image">\
          <img src="./images/22e0700c-192e-45df-94a2-389a9aa38964.jpg" />\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="118px" datasizeheight="23px" dataX="79" dataY="721" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">P&aacute;gina de la OMS</span></div></div></div></div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="63px" datasizeheight="58px" dataX="235" dataY="704"   alt="image">\
          <img src="./images/eb8eb47a-9336-4834-8f86-cc4cf910e5cc.png" />\
      </div>\
      <div id="s-Image_11" class="pie image firer click ie-background commentable non-processed"   datasizewidth="35px" datasizeheight="35px" dataX="27" dataY="48"   alt="image" systemName="./images/13a00661-8a5f-4f94-b354-e958cb88c93a.svg" overlay="#A9A9A9">\
          <svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M23.003 10.998h-19.429l10.104-9.263c.407-.373.435-1.006.062-1.413-.373-.406-1.006-.435-1.413-.062l-12 11-.015.017-.079.09-.051.061-.067.119-.029.055-.052.158-.01.033-.021.205.021.205.01.032.052.16.029.054.067.119.05.061.08.09.015.017 12 11c.191.176.434.263.676.263.27 0 .54-.109.737-.324.373-.407.346-1.039-.062-1.413l-10.104-9.264h19.429c.552 0 1-.447 1-1 0-.552-.448-1-1-1z"/></svg>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;