(function(window, undefined) {

  var jimLinks = {
    "a8d1bfcf-e065-403e-9b7c-957c793c6300" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Input_1" : [
        "397beb8d-ffb0-4c3a-8856-f8a31878ae04"
      ],
      "Image_11" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_40" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ]
    },
    "b9d3e1c7-98a9-4294-9667-3eb076358f22" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_11" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ]
    },
    "e76cc449-c950-4cb7-926f-29ace102db3e" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_2" : [
        "434b979c-2d8b-4683-90ec-199ca564ecb9"
      ],
      "Image_3" : [
        "b9d3e1c7-98a9-4294-9667-3eb076358f22"
      ]
    },
    "eaf77700-dcce-46f0-afeb-6ed29bfa6daf" : {
      "Image_11" : [
        "253aff73-3ca8-43e2-9730-6a71152a486f"
      ],
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "89eb57bb-2700-4d99-b18f-26da6c7f0d30" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "253aff73-3ca8-43e2-9730-6a71152a486f" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Button_1" : [
        "eaf77700-dcce-46f0-afeb-6ed29bfa6daf"
      ]
    },
    "57b4c937-8604-4aa0-91f3-5c565a4ac1af" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Button_2" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "4969546d-78e9-4e47-a247-973f212b4a81" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "a8106634-1a2d-4341-acb7-8587eaf2e38d" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_11" : [
        "23fd3a3e-8938-47d7-961e-d751cfa93711"
      ]
    },
    "3447245b-fa1e-4c7c-a504-d6878c155f98" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "434b979c-2d8b-4683-90ec-199ca564ecb9" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_11" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ]
    },
    "397beb8d-ffb0-4c3a-8856-f8a31878ae04" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Input_1" : [
        "397beb8d-ffb0-4c3a-8856-f8a31878ae04"
      ],
      "Image_11" : [
        "23fd3a3e-8938-47d7-961e-d751cfa93711"
      ]
    },
    "baf14e36-4450-4273-9242-bb57348ac5e3" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_14" : [
        "23fd3a3e-8938-47d7-961e-d751cfa93711"
      ]
    },
    "23fd3a3e-8938-47d7-961e-d751cfa93711" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Button_1" : [
        "baf14e36-4450-4273-9242-bb57348ac5e3"
      ],
      "Image_3" : [
        "baf14e36-4450-4273-9242-bb57348ac5e3"
      ],
      "Button_2" : [
        "397beb8d-ffb0-4c3a-8856-f8a31878ae04"
      ],
      "Image_28" : [
        "a8106634-1a2d-4341-acb7-8587eaf2e38d"
      ],
      "Paragraph_1" : [
        "397beb8d-ffb0-4c3a-8856-f8a31878ae04"
      ]
    },
    "a912af55-b5a7-4b47-8e4b-c36b451d40b4" : {
      "Image_15" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "1f332b31-31df-4f68-b2b1-7d1d471bf4e1" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "41f0b415-c70a-4de2-8e93-e2ce42598061" : {
      "Button_1" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Button_3" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Button_4" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Button_5" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_1" : [
        "57b4c937-8604-4aa0-91f3-5c565a4ac1af"
      ],
      "Text_3" : [
        "c51fc615-b4c3-47f4-b37e-e44ee275b05f"
      ],
      "Button_2" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_4" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Button_6" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_5" : [
        "23fd3a3e-8938-47d7-961e-d751cfa93711"
      ],
      "Button_9" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Button_7" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_7" : [
        "3447245b-fa1e-4c7c-a504-d6878c155f98"
      ],
      "Button_8" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_18" : [
        "4969546d-78e9-4e47-a247-973f212b4a81"
      ],
      "Button_10" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_2" : [
        "253aff73-3ca8-43e2-9730-6a71152a486f"
      ],
      "Image_3" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Image_6" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Image_8" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_9" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Image_10" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Image_11" : [
        "63f22249-8310-4bd7-984c-9ed8f872a8bb"
      ],
      "Button_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_12" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_23" : [
        "1f332b31-31df-4f68-b2b1-7d1d471bf4e1"
      ],
      "Image_24" : [
        "1f332b31-31df-4f68-b2b1-7d1d471bf4e1"
      ]
    },
    "fb4ebeae-3587-4e80-b3ce-90c09cebe25c" : {
      "Button_1" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Button_3" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Button_4" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Button_5" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_1" : [
        "57b4c937-8604-4aa0-91f3-5c565a4ac1af"
      ],
      "Text_3" : [
        "c51fc615-b4c3-47f4-b37e-e44ee275b05f"
      ],
      "Button_2" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_4" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Button_6" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_5" : [
        "23fd3a3e-8938-47d7-961e-d751cfa93711"
      ],
      "Button_9" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Button_7" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_7" : [
        "3447245b-fa1e-4c7c-a504-d6878c155f98"
      ],
      "Button_8" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_18" : [
        "4969546d-78e9-4e47-a247-973f212b4a81"
      ],
      "Button_10" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_2" : [
        "253aff73-3ca8-43e2-9730-6a71152a486f"
      ],
      "Image_3" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Image_6" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Image_8" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_9" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Image_10" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Image_11" : [
        "63f22249-8310-4bd7-984c-9ed8f872a8bb"
      ],
      "Button_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_12" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_23" : [
        "1f332b31-31df-4f68-b2b1-7d1d471bf4e1"
      ],
      "Image_24" : [
        "1f332b31-31df-4f68-b2b1-7d1d471bf4e1"
      ]
    },
    "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f" : {
      "Button_1" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Button_3" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Button_4" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Button_5" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_1" : [
        "57b4c937-8604-4aa0-91f3-5c565a4ac1af"
      ],
      "Text_3" : [
        "c51fc615-b4c3-47f4-b37e-e44ee275b05f"
      ],
      "Button_2" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_4" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Button_6" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_5" : [
        "23fd3a3e-8938-47d7-961e-d751cfa93711"
      ],
      "Button_9" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Button_7" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_7" : [
        "3447245b-fa1e-4c7c-a504-d6878c155f98"
      ],
      "Button_8" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_18" : [
        "4969546d-78e9-4e47-a247-973f212b4a81"
      ],
      "Button_10" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_2" : [
        "253aff73-3ca8-43e2-9730-6a71152a486f"
      ],
      "Image_3" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Image_6" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Image_8" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_9" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Image_10" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Image_11" : [
        "63f22249-8310-4bd7-984c-9ed8f872a8bb"
      ]
    },
    "68131ce7-c40d-4fb6-a803-281042859cd4" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "fb3c4a56-004c-48e3-9128-dd545a1e7a9b" : {
      "Rectangle_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ]
    },
    "294abed7-be54-4cca-8dc0-82d4935425f7" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_11" : [
        "9d0a8d35-f57a-4004-954b-98b1f94c83f8"
      ],
      "Image_40" : [
        "9d0a8d35-f57a-4004-954b-98b1f94c83f8"
      ]
    },
    "9d0a8d35-f57a-4004-954b-98b1f94c83f8" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_11" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_5" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ]
    },
    "2c6c00ca-dcc8-4998-abb3-4d811fbbe95a" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "c51fc615-b4c3-47f4-b37e-e44ee275b05f" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Input_1" : [
        "397beb8d-ffb0-4c3a-8856-f8a31878ae04"
      ],
      "Image_11" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_40" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ]
    },
    "2bae273d-ad8f-4f4d-96c0-48a3ad5b87c4" : {
      "Button_1" : [
        "2c6c00ca-dcc8-4998-abb3-4d811fbbe95a"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "2bae273d-ad8f-4f4d-96c0-48a3ad5b87c4"
      ],
      "Button_2" : [
        "fb3c4a56-004c-48e3-9128-dd545a1e7a9b"
      ]
    },
    "69ac48ba-f9cd-4fcf-8cfb-91311063d95b" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_34" : [
        "a8d1bfcf-e065-403e-9b7c-957c793c6300"
      ],
      "Button_1" : [
        "c51fc615-b4c3-47f4-b37e-e44ee275b05f"
      ],
      "Paragraph_1" : [
        "c51fc615-b4c3-47f4-b37e-e44ee275b05f"
      ],
      "Image_2" : [
        "9d0a8d35-f57a-4004-954b-98b1f94c83f8"
      ]
    },
    "f305a5dd-12d5-4dc8-9eeb-205f75a21685" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "6e60f637-1442-4dc5-8fcd-bb04d8bfe4cd" : {
      "Button_1" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Button_3" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Button_4" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Button_5" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_1" : [
        "57b4c937-8604-4aa0-91f3-5c565a4ac1af"
      ],
      "Text_3" : [
        "c51fc615-b4c3-47f4-b37e-e44ee275b05f"
      ],
      "Button_2" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_4" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Button_6" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_5" : [
        "23fd3a3e-8938-47d7-961e-d751cfa93711"
      ],
      "Button_9" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Button_7" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_7" : [
        "3447245b-fa1e-4c7c-a504-d6878c155f98"
      ],
      "Button_8" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_18" : [
        "4969546d-78e9-4e47-a247-973f212b4a81"
      ],
      "Button_10" : [
        "a912af55-b5a7-4b47-8e4b-c36b451d40b4"
      ],
      "Image_2" : [
        "253aff73-3ca8-43e2-9730-6a71152a486f"
      ],
      "Image_3" : [
        "89eb57bb-2700-4d99-b18f-26da6c7f0d30"
      ],
      "Image_6" : [
        "e76cc449-c950-4cb7-926f-29ace102db3e"
      ],
      "Image_8" : [
        "69ac48ba-f9cd-4fcf-8cfb-91311063d95b"
      ],
      "Image_9" : [
        "294abed7-be54-4cca-8dc0-82d4935425f7"
      ],
      "Image_10" : [
        "68131ce7-c40d-4fb6-a803-281042859cd4"
      ],
      "Image_11" : [
        "63f22249-8310-4bd7-984c-9ed8f872a8bb"
      ],
      "Button_11" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_12" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_23" : [
        "1f332b31-31df-4f68-b2b1-7d1d471bf4e1"
      ]
    },
    "63f22249-8310-4bd7-984c-9ed8f872a8bb" : {
      "Image_1" : [
        "b4cd7c31-fbc5-4440-bf25-1b8d1181ff7f"
      ],
      "Image_23" : [
        "1f332b31-31df-4f68-b2b1-7d1d471bf4e1"
      ]
    },
    "7c7dd059-91db-459e-8ecc-460fed6e7f44" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);